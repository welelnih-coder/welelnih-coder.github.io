// Edge Function: إرسال بريد للمدير عند وصول طلب جديد، أو عند ضغط «إرسال اختبار».
// الأسرار (RESEND_API_KEY, RESEND_FROM, WEBHOOK_SECRET, SITE_URL) تُحفظ في Supabase Secrets فقط.
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.45.0'
const cors = { 'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Headers': 'authorization, content-type, apikey, x-client-info' }
const json = (b: unknown, s = 200) => new Response(JSON.stringify(b), { status: s, headers: { ...cors, 'Content-Type': 'application/json' } })
Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: cors })
  const url = Deno.env.get('SUPABASE_URL')!
  const db = createClient(url, Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!)
  let body: any = {}; try { body = await req.json() } catch { /* empty */ }
  let subject: string, text: string
  if (body.test) {
    const u = createClient(url, Deno.env.get('SUPABASE_ANON_KEY')!, { global: { headers: { Authorization: req.headers.get('Authorization') ?? '' } } })
    const { data } = await u.rpc('is_admin'); if (data !== true) return json({ ok: false, error: 'forbidden' }, 403)
    subject = 'اختبار إشعارات سُنّي'; text = 'إذا وصلتك هذه الرسالة فإشعارات البريد تعمل.'
  } else {
    if (req.headers.get('x-webhook-secret') !== Deno.env.get('WEBHOOK_SECRET')) return json({ ok: false }, 401)
    const r = body.record; if (!r?.order_number) return json({ ok: false }, 400)
    subject = `طلب جديد رقم ${r.order_number}`
    text = `وصل طلب جديد رقم ${r.order_number} بقيمة ${r.total} ${r.currency}.\n${Deno.env.get('SITE_URL') ?? ''}/admin/orders/${r.id}`
  }
  const { data: cfg } = await db.from('notification_settings').select('enabled,config').eq('channel', 'email').single()
  if (!body.test && !cfg?.enabled) return json({ ok: true, skipped: true })
  const fail = async (m: string) => { await db.from('notification_settings').update({ state: 'error', last_error: m }).eq('channel', 'email'); return json({ ok: false, error: m }, 200) }
  const to = cfg?.config?.to as string | undefined; const key = Deno.env.get('RESEND_API_KEY'); const from = Deno.env.get('RESEND_FROM')
  if (!to) return fail('لم يُحدَّد بريد المستلم.')
  if (!key || !from) return fail('أسرار البريد (RESEND_API_KEY / RESEND_FROM) غير مضبوطة.')
  try {
    const res = await fetch('https://api.resend.com/emails', { method: 'POST', headers: { Authorization: `Bearer ${key}`, 'Content-Type': 'application/json' }, body: JSON.stringify({ from, to: [to], subject, text }) })
    if (!res.ok) return fail(`رفض مزود البريد الطلب (${res.status}).`)
  } catch { return fail('تعذّر الاتصال بمزود البريد.') }
  await db.from('notification_settings').update({ state: 'active', last_error: null }).eq('channel', 'email')
  return json({ ok: true })
})
