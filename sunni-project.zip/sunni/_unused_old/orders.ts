// أرقام الطلبات والرموز السرية تُحفظ في جهاز العميل فقط لمتابعة طلباته
const KEY = 'sunni_orders'
export interface MyOrder { number: number; token: string; at: string }
export function myOrders(): MyOrder[] {
  try { return JSON.parse(localStorage.getItem(KEY) || '[]') } catch { return [] }
}
export function rememberOrder(o: MyOrder) {
  try { localStorage.setItem(KEY, JSON.stringify([o, ...myOrders()].slice(0, 30))) } catch { /* ignore */ }
}
