import { useCallback, useEffect, useState } from 'react'
import { supabase } from './supabase'
import type { Category, Product } from './types'

export function useCatalog() {
  const [products, setP] = useState<Product[]>([])
  const [cats, setC] = useState<Category[]>([])
  const [loading, setL] = useState(true)
  const [error, setE] = useState<string | null>(null)

  const load = useCallback(async () => {
    setL(true); setE(null)
    const [p, c] = await Promise.all([
      supabase.from('products').select('*, product_images(path,is_main,sort_order)').eq('is_published', true).order('created_at', { ascending: false }),
      supabase.from('categories').select('*').order('sort_order')
    ])
    if (p.error || c.error) setE(navigator.onLine ? 'تعذر تحميل المنتجات.' : 'لا يوجد اتصال بالإنترنت.')
    else { setP(p.data as Product[]); setC(c.data as Category[]) }
    setL(false)
  }, [])
  useEffect(() => { load() }, [load])
  return { products, cats, loading, error, reload: load }
}
