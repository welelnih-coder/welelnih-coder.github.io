export function money(n: number, currency = 'MRU') {
  return `${new Intl.NumberFormat('ar', { maximumFractionDigits: 2 }).format(n)} ${currency}`
}
export function mainImage(p: { product_images: { path: string; is_main: boolean; sort_order: number }[] }) {
  const imgs = [...p.product_images].sort((a, b) => Number(b.is_main) - Number(a.is_main) || a.sort_order - b.sort_order)
  return imgs[0]?.path ?? null
}
export function inStock(p: { is_available: boolean; stock: number }) { return p.is_available && p.stock > 0 }
