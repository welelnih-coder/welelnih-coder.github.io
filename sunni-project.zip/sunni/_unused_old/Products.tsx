import { useMemo } from 'react'
import { Link, useSearchParams } from 'react-router-dom'
import { useCatalog } from '../lib/useProducts'
import { inStock } from '../lib/format'
import ProductCard from '../components/ProductCard'
import { Empty, ErrorBox, Loading } from '../components/State'

export default function Products() {
  const [sp, setSp] = useSearchParams()
  const { products, cats, loading, error, reload } = useCatalog()
  const q = sp.get('q')?.trim() ?? ''
  const cat = sp.get('cat') ?? ''
  const avail = sp.get('avail') === '1'
  const offers = sp.get('offers') === '1'
  const sort = sp.get('sort') ?? 'new'
  const min = Number(sp.get('min')) || 0
  const max = Number(sp.get('max')) || 0

  const set = (k: string, v: string) => { const n = new URLSearchParams(sp); v ? n.set(k, v) : n.delete(k); setSp(n, { replace: true }) }

  const list = useMemo(() => {
    const catName = (id: string | null) => cats.find(c => c.id === id)?.name ?? ''
    let r = products.filter(p => {
      if (cat && p.category_id !== cat) return false
      if (avail && !inStock(p)) return false
      if (offers && !(p.compare_at_price && p.compare_at_price > p.price)) return false
      if (min && p.price < min) return false
      if (max && p.price > max) return false
      if (q) {
        const hay = `${p.name} ${p.description ?? ''} ${catName(p.category_id)}`.toLowerCase()
        if (!hay.includes(q.toLowerCase())) return false
      }
      return true
    })
    if (sort === 'asc') r = [...r].sort((a, b) => a.price - b.price)
    else if (sort === 'desc') r = [...r].sort((a, b) => b.price - a.price)
    else r = [...r].sort((a, b) => b.created_at.localeCompare(a.created_at))
    return r
  }, [products, cats, q, cat, avail, offers, sort, min, max])

  return (
    <div className="max-w-6xl mx-auto px-5 py-10">
      <h1 className="font-display text-4xl mb-6">العطور</h1>
      <div className="grid gap-3 md:grid-cols-[1fr_auto_auto] mb-3">
        <input className="input" placeholder="ابحث بالاسم أو الوصف أو التصنيف" defaultValue={q}
          onKeyDown={e => { if (e.key === 'Enter') set('q', (e.target as HTMLInputElement).value) }}
          onBlur={e => set('q', e.target.value)} />
        <select className="input" aria-label="التصنيف" value={cat} onChange={e => set('cat', e.target.value)}>
          <option value="">كل التصنيفات</option>
          {cats.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
        </select>
        <select className="input" aria-label="الترتيب" value={sort} onChange={e => set('sort', e.target.value)}>
          <option value="new">الأحدث</option><option value="asc">السعر: من الأقل</option><option value="desc">السعر: من الأعلى</option>
        </select>
      </div>
      <div className="flex flex-wrap items-center gap-4 mb-8 text-sm">
        <label className="flex items-center gap-2"><input type="checkbox" checked={avail} onChange={e => set('avail', e.target.checked ? '1' : '')} /> المتوفر فقط</label>
        <label className="flex items-center gap-2"><input type="checkbox" checked={offers} onChange={e => set('offers', e.target.checked ? '1' : '')} /> العروض</label>
        <input className="input !w-28 !py-1.5" inputMode="numeric" placeholder="أقل سعر" defaultValue={min || ''} onBlur={e => set('min', e.target.value)} />
        <input className="input !w-28 !py-1.5" inputMode="numeric" placeholder="أعلى سعر" defaultValue={max || ''} onBlur={e => set('max', e.target.value)} />
      </div>
      {loading ? <Loading /> : error ? <ErrorBox msg={error} retry={reload} /> :
        products.length === 0 ? <Empty title="لا توجد عطور منشورة حاليًا" text="ستظهر العطور هنا بمجرد إضافتها ونشرها." /> :
        list.length === 0 ? <Empty title="لا توجد نتائج مطابقة" text="جرّب كلمات أخرى أو أزل بعض عوامل التصفية."><Link to="/products" className="btn">عرض كل المنتجات</Link></Empty> :
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 md:gap-6">{list.map(p => <ProductCard key={p.id} p={p} />)}</div>}
    </div>
  )
}
