import { ReactNode } from 'react'
export const Loading = () => <div className="py-24 text-center text-mute" role="status">جارٍ التحميل…</div>
export const ErrorBox = ({ msg, retry }: { msg: string; retry?: () => void }) => (
  <div className="py-20 text-center"><p className="text-ivory/80 mb-4">{msg}</p>{retry && <button className="btn-o" onClick={retry}>أعد المحاولة</button>}</div>
)
export const Empty = ({ title, text, children }: { title: string; text?: string; children?: ReactNode }) => (
  <div className="bg-char2 py-12 px-6 text-center"><h3 className="text-lg font-normal mb-1">{title}</h3>{text && <p className="text-mute mb-4">{text}</p>}{children}</div>
)
