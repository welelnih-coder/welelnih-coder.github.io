import { Link } from 'react-router-dom'
import { useCart } from '../lib/cart'
import { useSettings } from '../lib/settings'
import { imageUrl } from '../lib/supabase'
import { money } from '../lib/format'
import { Empty } from '../components/State'

export default function Cart() {
  const { lines, subtotal, setQty, remove } = useCart()
  const { settings } = useSettings()
  const cur = settings?.currency ?? 'MRU'
  if (!lines.length) return <div className="max-w-3xl mx-auto px-5 py-16"><Empty title="سلتك فارغة" text="أضف عطرًا لتبدأ طلبك."><Link to="/products" className="btn">تصفح العطور</Link></Empty></div>
  return (
    <div className="max-w-3xl mx-auto px-5 py-10">
      <h1 className="font-display text-4xl mb-6">سلة التسوق</h1>
      <ul className="divide-y divide-ivory/10">
        {lines.map(l => (
          <li key={l.id} className="py-4 flex gap-4">
            <div className="w-20 h-24 bg-brown shrink-0 overflow-hidden">{l.image && <img src={imageUrl(l.image)!} alt="" className="w-full h-full object-cover" />}</div>
            <div className="flex-1">
              <div>{l.name}</div>
              <div className="text-copper text-sm">{money(l.price, cur)}</div>
              <div className="flex items-center gap-3 mt-2">
                <div className="flex items-center border border-ivory/20">
                  <button className="w-9 h-9" aria-label="تقليل" onClick={() => setQty(l.id, l.qty - 1)}>−</button>
                  <span className="w-8 text-center">{l.qty}</span>
                  <button className="w-9 h-9" aria-label="زيادة" disabled={l.qty >= l.stock} onClick={() => setQty(l.id, l.qty + 1)}>+</button>
                </div>
                <button className="text-sm text-mute underline" onClick={() => remove(l.id)}>حذف</button>
              </div>
              {l.qty >= l.stock && <p className="text-xs text-mute mt-1">وصلت إلى أقصى كمية متاحة.</p>}
            </div>
            <div className="text-end">{money(l.price * l.qty, cur)}</div>
          </li>
        ))}
      </ul>
      <div className="border-t border-ivory/10 pt-5 mt-2 flex justify-between text-lg"><span>المجموع</span><span>{money(subtotal, cur)}</span></div>
      <p className="text-sm text-mute mt-1">تُضاف تكلفة التوصيل عند إتمام الطلب إن وُجدت.</p>
      <div className="flex gap-3 mt-6">
        <Link to="/products" className="btn-o">متابعة التسوق</Link>
        <Link to="/checkout" className="btn flex-1 text-center">إتمام الطلب</Link>
      </div>
    </div>
  )
}
