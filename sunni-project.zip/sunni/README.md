# سُنّي — المتجر العام (المرحلة 3)

1. نفّذ ملف sunni-schema.sql في Supabase (SQL Editor).
2. انسخ .env.example إلى .env وضع قيمتي VITE_SUPABASE_URL و VITE_SUPABASE_ANON_KEY (من Project Settings ← API).
3. npm install ثم npm run dev للتجربة، أو npm run build للنشر.
4. النشر: Netlify أو Vercel أو Cloudflare Pages (ملف public/_redirects يعالج المسارات).

لا يضيف المشروع أي منتجات؛ تظهر الأقسام فقط عند وجود بيانات حقيقية من قاعدة البيانات.
لوحة الإدارة (الدخول، المنتجات، التصنيفات، رفع الصور، كلمة المرور) على المسار /admin — المرحلة 4.
تمت المراحل 1–6. راجع DEPLOY.md للإعداد والنشر وقائمة الاختبار.
