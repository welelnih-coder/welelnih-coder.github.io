import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { supabase } from '../lib/supabase'
import { money } from '../lib/util'
type O = { id: string; order_number: number; customer_name: string; phone: string; total: number; currency: string; status: string; created_at: string }
export default function Orders() {
  const [rows, setRows] = useState<O[]>([]); const [sts, setSts] = useState<{ key: string; label: string }[]>([]); const [loading, setLoading] = useState(true); const [err, setErr] = useState(false)
  const [q, setQ] = useState(''); const [st, setSt] = useState(''); const [from, setFrom] = useState(''); const [to, setTo] = useState('')
  useEffect(() => { supabase.from('order_statuses').select('key,label').order('sort_order').then(r => setSts(r.data ?? [])) }, [])
  useEffect(() => {
    setLoading(true)
    const t = setTimeout(async () => {
      let qb = supabase.from('orders').select('id,order_number,customer_name,phone,total,currency,status,created_at').order('created_at', { ascending: false }).limit(200)
      const term = q.trim()
      if (/^\d{1,9}$/.test(term) && term.length <= 5) qb = qb.eq('order_number', Number(term))
      else if (term) qb = qb.ilike('phone', `%${term.replace(/[%,()]/g, '')}%`)
      if (st) qb = qb.eq('status', st)
      if (from) qb = qb.gte('created_at', new Date(from).toISOString())
      if (to) qb = qb.lte('created_at', new Date(to + 'T23:59:59').toISOString())
      const { data, error } = await qb; setErr(!!error); setRows((data ?? []) as O[]); setLoading(false)
    }, 250)
    return () => clearTimeout(t)
  }, [q, st, from, to])
  const label = (k: string) => sts.find(s => s.key === k)?.label ?? k
  return (
    <div>
      <h1 className="font-display text-3xl mb-5">الطلبات</h1>
      <div className="grid sm:grid-cols-4 gap-2 mb-4">
        <input className="inp" placeholder="رقم الطلب أو الهاتف" value={q} onChange={e => setQ(e.target.value)} />
        <select className="inp" value={st} onChange={e => setSt(e.target.value)}><option value="">كل الحالات</option>{sts.map(s => <option key={s.key} value={s.key}>{s.label}</option>)}</select>
        <input className="inp" type="date" aria-label="من تاريخ" value={from} onChange={e => setFrom(e.target.value)} />
        <input className="inp" type="date" aria-label="إلى تاريخ" value={to} onChange={e => setTo(e.target.value)} />
      </div>
      {err ? <p className="text-mute">تعذّر التحميل.</p> : loading ? <p className="text-mute">جارٍ التحميل…</p> : rows.length === 0 ? <p className="text-mute bg-char2 p-8 text-center">لا توجد طلبات مطابقة.</p> :
        <ul className="bg-char2 divide-y divide-ivory/15">{rows.map(o => (
          <li key={o.id}><Link to={`/admin/orders/${o.id}`} className="p-3 flex justify-between gap-3 hover:bg-brown/30">
            <span><b className="font-medium">#{o.order_number}</b> · {o.customer_name}<span className="block text-xs text-mute" dir="ltr">{o.phone}</span></span>
            <span className="text-end text-sm"><span className="text-copper">{label(o.status)}</span><span className="block text-xs text-mute">{money(o.total, o.currency)} · {new Date(o.created_at).toLocaleDateString('ar')}</span></span>
          </Link></li>))}</ul>}
    </div>
  )
}
