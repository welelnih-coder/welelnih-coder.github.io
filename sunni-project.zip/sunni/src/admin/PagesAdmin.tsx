import { useEffect, useState } from 'react'
import { supabase } from '../lib/supabase'
type P = { slug: string; title: string; body: string; published: boolean }
const STD = [{ slug: 'privacy', title: 'سياسة الخصوصية' }, { slug: 'orders-policy', title: 'سياسة الطلبات والإلغاء' }, { slug: 'delivery', title: 'معلومات التوصيل' }]
export default function PagesAdmin() {
  const [list, setList] = useState<P[]>([]); const [sel, setSel] = useState<P | null>(null); const [msg, setMsg] = useState(''); const [busy, setBusy] = useState(false)
  const load = () => supabase.from('pages').select('*').order('title').then(r => setList((r.data ?? []) as P[]))
  useEffect(() => { load() }, [])
  const create = async (slug: string, title: string) => { const { error } = await supabase.from('pages').insert({ slug, title, body: '', published: false }); error ? setMsg('تعذّر الإنشاء.') : load() }
  const custom = () => { const title = prompt('عنوان الصفحة الجديدة')?.trim(); if (title) create('page-' + Math.random().toString(36).slice(2, 8), title) }
  const save = async () => { if (!sel || busy) return; setBusy(true); const { error } = await supabase.from('pages').update({ title: sel.title.trim(), body: sel.body, published: sel.published }).eq('slug', sel.slug); setBusy(false); setMsg(error ? 'تعذّر الحفظ.' : 'تم الحفظ.'); if (!error) load() }
  const del = async () => { if (!sel || !confirm('حذف هذه الصفحة؟')) return; const { error } = await supabase.from('pages').delete().eq('slug', sel.slug); if (!error) { setSel(null); load() } else setMsg('تعذّر الحذف.') }
  const missing = STD.filter(s => !list.some(p => p.slug === s.slug))
  return (
    <div className="max-w-xl">
      <h1 className="font-display text-3xl mb-4">صفحات الموقع</h1>
      <div className="flex flex-wrap gap-2 mb-4">{missing.map(s => <button key={s.slug} className="btn btn-o !py-1.5 text-sm" onClick={() => create(s.slug, s.title)}>+ {s.title}</button>)}<button className="btn btn-o !py-1.5 text-sm" onClick={custom}>+ صفحة جديدة</button></div>
      {list.length === 0 ? <p className="text-mute bg-char2 p-6 text-center">لا توجد صفحات. أنشئ صفحة من الأزرار أعلاه.</p> :
        <ul className="bg-char2 divide-y divide-ivory/15 mb-5">{list.map(p => <li key={p.slug}><button className={`w-full text-start p-3 flex justify-between ${sel?.slug === p.slug ? 'bg-brown/40' : ''}`} onClick={() => { setSel(p); setMsg('') }}><span>{p.title}</span><span className="text-xs text-mute">{p.published ? 'منشورة' : 'مسودة'}</span></button></li>)}</ul>}
      {sel && <div className="space-y-3">
        <input className="inp" value={sel.title} onChange={e => setSel({ ...sel, title: e.target.value })} />
        <textarea className="inp" rows={10} placeholder="نص الصفحة" value={sel.body} onChange={e => setSel({ ...sel, body: e.target.value })} />
        <label className="flex gap-2 text-sm"><input type="checkbox" checked={sel.published} onChange={e => setSel({ ...sel, published: e.target.checked })} />منشورة (تظهر في التذييل)</label>
        <div className="flex gap-3"><button className="btn" disabled={busy} onClick={save}>حفظ</button><button className="btn btn-o" onClick={del}>حذف</button></div>
      </div>}
      {msg && <p role="status" className="text-sm text-copper mt-3">{msg}</p>}
    </div>
  )
}
