import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { supabase } from '../lib/supabase'
import { PRODUCT_SELECT, inStock, mainImage, money } from '../lib/util'
import type { Category, Product } from '../lib/types'
type P = Product & { is_published: boolean }
export default function Products() {
  const [items, setItems] = useState<P[]>([]); const [cats, setCats] = useState<Category[]>([]); const [loading, setLoading] = useState(true); const [err, setErr] = useState('')
  const [q, setQ] = useState(''); const [cat, setCat] = useState(''); const [av, setAv] = useState('')
  const load = () => supabase.from('products').select(PRODUCT_SELECT).order('sort_order').order('created_at', { ascending: false })
    .then(r => { if (r.error) setErr('تعذّر تحميل المنتجات.'); else setItems((r.data ?? []) as P[]); setLoading(false) })
  useEffect(() => { load(); supabase.from('categories').select('*').order('sort_order').then(r => setCats((r.data ?? []) as Category[])) }, [])
  const shown = items.filter(p => p.name.includes(q.trim()) && (!cat || p.category_id === cat) && (!av || (av === 'in') === inStock(p)))
  const patch = async (id: string, v: Partial<P>) => { const { error } = await supabase.from('products').update(v).eq('id', id); error ? setErr('تعذّر الحفظ.') : load() }
  const del = async (p: P) => {
    if (!confirm(`حذف «${p.name}» نهائيًا؟ لا يمكن التراجع.`)) return
    const paths = p.product_images.map(i => i.path)
    const { error } = await supabase.from('products').delete().eq('id', p.id)
    if (error) return setErr('تعذّر الحذف.')
    if (paths.length) await supabase.storage.from('product-images').remove(paths)
    load()
  }
  return (
    <div>
      <div className="flex justify-between items-center mb-5"><h1 className="font-display text-3xl">المنتجات</h1><Link to="/admin/products/new" className="btn !py-2">إضافة منتج</Link></div>
      <div className="grid sm:grid-cols-3 gap-2 mb-4">
        <input className="inp" placeholder="بحث بالاسم" value={q} onChange={e => setQ(e.target.value)} />
        <select className="inp" value={cat} onChange={e => setCat(e.target.value)}><option value="">كل التصنيفات</option>{cats.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}</select>
        <select className="inp" value={av} onChange={e => setAv(e.target.value)}><option value="">كل الحالات</option><option value="in">متوفر</option><option value="out">غير متوفر</option></select>
      </div>
      {err && <p role="alert" className="text-sm text-[#e0a58a] mb-3">{err}</p>}
      {loading ? <p className="text-mute">جارٍ التحميل…</p> : shown.length === 0 ? <p className="text-mute bg-char2 p-8 text-center">لا توجد منتجات. ابدأ بإضافة أول منتج.</p> :
        <ul className="bg-char2 divide-y divide-ivory/15">{shown.map(p => (
          <li key={p.id} className="p-3 flex gap-3 items-center">
            <div className="w-14 h-16 bg-brown/40 shrink-0">{mainImage(p) && <img src={mainImage(p)!} alt="" loading="lazy" className="w-full h-full object-contain" />}</div>
            <div className="flex-1 min-w-0"><p className="truncate font-medium">{p.name}</p>
              <p className="text-xs text-mute">{money(p.price)} · الكمية {p.stock} · {p.is_published ? 'منشور' : 'مسودة'}{p.is_featured ? ' · مميز' : ''}</p></div>
            <div className="flex flex-col sm:flex-row gap-x-3 text-sm items-end">
              <Link className="text-copper" to={`/admin/products/${p.id}`}>تعديل</Link>
              <button className="text-mute hover:text-ivory" onClick={() => patch(p.id, { is_published: !p.is_published })}>{p.is_published ? 'إخفاء' : 'نشر'}</button>
              <button className="text-mute hover:text-ivory" onClick={() => del(p)}>حذف</button>
            </div>
          </li>))}</ul>}
    </div>
  )
}
