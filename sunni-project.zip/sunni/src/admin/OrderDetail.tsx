import { useEffect, useState } from 'react'
import { Link, useParams } from 'react-router-dom'
import { supabase } from '../lib/supabase'
import { money } from '../lib/util'
type Item = { id: string; product_name: string; unit_price: number; quantity: number; line_total: number }
type Log = { id: number; from_status: string | null; to_status: string; changed_at: string }
type O = { id: string; order_number: number; customer_name: string; phone: string; city: string; address: string | null; notes: string | null; subtotal: number; delivery_fee: number; total: number; currency: string; status: string; internal_notes: string | null; created_at: string; updated_at: string }
export default function OrderDetail() {
  const { id } = useParams()
  const [o, setO] = useState<O | null>(null); const [items, setItems] = useState<Item[]>([]); const [log, setLog] = useState<Log[]>([]); const [sts, setSts] = useState<{ key: string; label: string }[]>([])
  const [note, setNote] = useState(''); const [msg, setMsg] = useState(''); const [busy, setBusy] = useState(false); const [state, setState] = useState<'load' | 'ok' | 'none'>('load')
  const load = async () => {
    const [a, b, c, d] = await Promise.all([
      supabase.from('orders').select('*').eq('id', id!).maybeSingle(), supabase.from('order_items').select('*').eq('order_id', id!),
      supabase.from('order_status_log').select('*').eq('order_id', id!).order('changed_at'), supabase.from('order_statuses').select('key,label').order('sort_order')])
    if (!a.data) return setState('none')
    setO(a.data as O); setNote(a.data.internal_notes ?? ''); setItems((b.data ?? []) as Item[]); setLog((c.data ?? []) as Log[]); setSts(d.data ?? []); setState('ok')
  }
  useEffect(() => { load() }, [id])
  const label = (k: string | null) => sts.find(s => s.key === k)?.label ?? k ?? '—'
  const change = async (v: string) => {
    if (!o || v === o.status || busy) return
    if (v === 'cancelled' && !confirm('إلغاء الطلب سيعيد الكميات إلى المخزون. متابعة؟')) return
    setBusy(true); setMsg('')
    const { error } = await supabase.from('orders').update({ status: v }).eq('id', o.id)
    setBusy(false); if (error) setMsg('تعذّر تغيير الحالة.'); else { setMsg('تم تحديث الحالة.'); load() }
  }
  const saveNote = async () => { const { error } = await supabase.from('orders').update({ internal_notes: note.trim() || null }).eq('id', o!.id); setMsg(error ? 'تعذّر حفظ الملاحظة.' : 'تم حفظ الملاحظة.') }
  if (state === 'load') return <p className="text-mute">جارٍ التحميل…</p>
  if (!o) return <p className="text-mute">الطلب غير موجود. <Link className="text-copper" to="/admin/orders">رجوع</Link></p>
  const fmt = (d: string) => new Date(d).toLocaleString('ar')
  return (
    <div className="max-w-xl space-y-5">
      <Link to="/admin/orders" className="text-sm text-copper">← كل الطلبات</Link>
      <h1 className="font-display text-3xl">طلب #{o.order_number}</h1>
      <section className="bg-char2 p-4 text-sm space-y-1">
        <p>الاسم: {o.customer_name}</p><p>الهاتف: <a dir="ltr" className="text-copper" href={`tel:${o.phone}`}>{o.phone}</a></p>
        <p>المدينة: {o.city}</p>{o.address && <p>العنوان: {o.address}</p>}{o.notes && <p>ملاحظات العميل: {o.notes}</p>}
        <p className="text-mute">أُنشئ: {fmt(o.created_at)} · آخر تحديث: {fmt(o.updated_at)}</p>
      </section>
      <ul className="bg-char2 divide-y divide-ivory/15 text-sm">{items.map(i => <li key={i.id} className="p-3 flex justify-between"><span>{i.product_name} × {i.quantity}</span><span>{money(i.line_total, o.currency)}</span></li>)}
        <li className="p-3 flex justify-between text-mute"><span>التوصيل</span><span>{money(o.delivery_fee, o.currency)}</span></li>
        <li className="p-3 flex justify-between font-medium"><span>الإجمالي</span><span>{money(o.total, o.currency)}</span></li></ul>
      <div><label className="text-sm block mb-1">حالة الطلب</label>
        <select className="inp" value={o.status} disabled={busy} onChange={e => change(e.target.value)}>{sts.map(s => <option key={s.key} value={s.key}>{s.label}</option>)}</select></div>
      <div><label className="text-sm block mb-1">ملاحظات داخلية</label><textarea className="inp" rows={3} value={note} onChange={e => setNote(e.target.value)} /><button className="btn !py-2 mt-2" onClick={saveNote}>حفظ الملاحظة</button></div>
      {msg && <p role="status" className="text-sm text-copper">{msg}</p>}
      <div><h2 className="text-sm mb-2">سجل الحالات</h2><ul className="text-xs text-mute space-y-1">{log.map(l => <li key={l.id}>{fmt(l.changed_at)} — {l.from_status ? `${label(l.from_status)} ← ` : ''}{label(l.to_status)}</li>)}</ul></div>
    </div>
  )
}
