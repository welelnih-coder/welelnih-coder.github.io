import { useState } from 'react'
import { Navigate } from 'react-router-dom'
import { supabase } from '../lib/supabase'
import { useAuth } from '../lib/auth'
export default function Login() {
  const { user, isAdmin } = useAuth()
  const [email, setEmail] = useState(''); const [pw, setPw] = useState(''); const [busy, setBusy] = useState(false); const [msg, setMsg] = useState('')
  const [fails, setFails] = useState(0)
  if (user && isAdmin) return <Navigate to="/admin" replace />
  const go = async (e: React.FormEvent) => {
    e.preventDefault(); if (busy) return
    if (fails >= 5) return setMsg('محاولات كثيرة. انتظر دقيقة ثم أعد المحاولة.')
    setBusy(true); setMsg('')
    const { error } = await supabase.auth.signInWithPassword({ email: email.trim(), password: pw })
    setBusy(false)
    if (error) { const n = fails + 1; setFails(n); if (n >= 5) setTimeout(() => setFails(0), 60000); setMsg('بيانات الدخول غير صحيحة.') }
  }
  const reset = async () => {
    if (!email.trim()) return setMsg('أدخل بريدك الإلكتروني أولًا.')
    const { error } = await supabase.auth.resetPasswordForEmail(email.trim(), { redirectTo: `${location.origin}/admin/security` })
    setMsg(error ? 'تعذّر إرسال رابط الاستعادة. تأكد من إعداد البريد في Supabase.' : 'إن كان البريد مسجلًا فستصله رسالة استعادة.')
  }
  return (
    <div className="min-h-screen grid place-items-center px-5">
      <form onSubmit={go} className="w-full max-w-sm bg-char2 p-7 space-y-3">
        <h1 className="font-display text-3xl mb-2">دخول الإدارة</h1>
        <input className="inp" type="email" required dir="ltr" placeholder="البريد الإلكتروني" value={email} onChange={e => setEmail(e.target.value)} autoComplete="username" />
        <input className="inp" type="password" required dir="ltr" placeholder="كلمة المرور" value={pw} onChange={e => setPw(e.target.value)} autoComplete="current-password" />
        {msg && <p role="alert" className="text-sm text-[#e0a58a]">{msg}</p>}
        <button className="btn w-full" disabled={busy}>{busy ? 'جارٍ الدخول…' : 'دخول'}</button>
        <button type="button" className="text-sm text-mute hover:text-ivory" onClick={reset}>نسيت كلمة المرور؟</button>
      </form>
    </div>
  )
}
