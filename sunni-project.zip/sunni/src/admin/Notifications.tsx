import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { supabase } from '../lib/supabase'
type Ch = { channel: string; enabled: boolean; state: string; last_error: string | null; config: { to?: string } }
type In = { id: number; order_id: string | null; message: string; is_read: boolean; created_at: string }
const STATE: Record<string, string> = { active: 'مفعلة وتعمل', disabled: 'غير مفعلة', needs_setup: 'تحتاج إلى إعداد', error: 'حدث خطأ في الإرسال' }
export default function Notifications() {
  const [chs, setChs] = useState<Ch[]>([]); const [inbox, setInbox] = useState<In[]>([]); const [to, setTo] = useState(''); const [on, setOn] = useState(false)
  const [msg, setMsg] = useState(''); const [busy, setBusy] = useState(false); const [perm, setPerm] = useState(typeof Notification === 'undefined' ? 'unsupported' : Notification.permission)
  const load = async () => {
    const [a, b] = await Promise.all([supabase.from('notification_settings').select('*'), supabase.from('admin_inbox').select('*').order('created_at', { ascending: false }).limit(30)])
    const rows = (a.data ?? []) as Ch[]; setChs(rows); setInbox((b.data ?? []) as In[])
    const em = rows.find(r => r.channel === 'email'); setTo(em?.config?.to ?? ''); setOn(!!em?.enabled)
  }
  useEffect(() => { load() }, [])
  const email = chs.find(c => c.channel === 'email')
  const saveEmail = async () => {
    if (on && !/^\S+@\S+\.\S+$/.test(to)) return setMsg('أدخل بريدًا صحيحًا.')
    setBusy(true)
    const keep = email?.state === 'active' && email.config?.to === to
    const { error } = await supabase.from('notification_settings').update({ enabled: on, config: { to }, state: !on ? 'disabled' : keep ? 'active' : 'needs_setup' }).eq('channel', 'email')
    setBusy(false); setMsg(error ? 'تعذّر الحفظ.' : on ? 'تم الحفظ. اضغط «إرسال اختبار» للتأكد أنه يعمل فعلًا.' : 'تم الحفظ.'); load()
  }
  const test = async () => {
    setBusy(true); setMsg('')
    const { data, error } = await supabase.functions.invoke('notify-order', { body: { test: true } })
    setBusy(false)
    if (error) setMsg('تعذّر الوصول إلى الدالة. تأكد أنها منشورة (راجع DEPLOY.md).')
    else setMsg(data?.ok ? 'أُرسل البريد التجريبي. تحقق من صندوق الوارد.' : `فشل الإرسال: ${data?.error ?? 'سبب غير معروف'}`)
    load()
  }
  const readAll = async () => { await supabase.from('admin_inbox').update({ is_read: true }).eq('is_read', false); load() }
  const askPerm = async () => setPerm(await Notification.requestPermission())
  const row = (name: string, state: string, extra?: string) => <li className="p-3 flex justify-between gap-3"><span>{name}</span><span className="text-sm text-end"><span className={state === 'active' ? 'text-copper' : state === 'error' ? 'text-[#e0a58a]' : 'text-mute'}>{STATE[state]}</span>{extra && <span className="block text-xs text-mute">{extra}</span>}</span></li>
  return (
    <div className="max-w-xl space-y-6">
      <h1 className="font-display text-3xl">التنبيهات</h1>
      <ul className="bg-char2 divide-y divide-ivory/15">
        {row('صندوق الإشعارات داخل اللوحة', chs.find(c => c.channel === 'admin_inbox')?.enabled ? 'active' : 'disabled')}
        {row('إشعارات المتصفح (أثناء فتح اللوحة)', perm === 'granted' ? 'active' : 'needs_setup', perm === 'unsupported' ? 'متصفحك لا يدعمها' : perm === 'denied' ? 'محظورة في إعدادات المتصفح' : undefined)}
        {row('البريد الإلكتروني', email?.state ?? 'needs_setup', email?.state === 'error' ? email.last_error ?? undefined : undefined)}
        {row('إشعارات Push عند إغلاق اللوحة', 'needs_setup', 'غير مُنفَّذة بعد؛ تحتاج مفاتيح VAPID وخدمة Service Worker')}
        {row('الرسائل النصية SMS', 'needs_setup', 'تحتاج مزود خدمة وحسابًا مدفوعًا')}
      </ul>
      {perm === 'default' && <button className="btn btn-o" onClick={askPerm}>السماح بإشعارات المتصفح</button>}
      <section className="bg-char2 p-4 space-y-3"><h2 className="text-sm text-copper">إشعارات البريد للمدير</h2>
        <input className="inp" dir="ltr" type="email" placeholder="بريد المستلم" value={to} onChange={e => setTo(e.target.value)} />
        <label className="flex gap-2 text-sm"><input type="checkbox" checked={on} onChange={e => setOn(e.target.checked)} />تفعيل عند وصول طلب جديد</label>
        <div className="flex gap-3"><button className="btn !py-2" disabled={busy} onClick={saveEmail}>حفظ</button><button className="btn btn-o !py-2" disabled={busy || !email?.config?.to} onClick={test}>إرسال اختبار</button></div>
        {msg && <p role="status" className="text-sm text-copper">{msg}</p>}
      </section>
      <section><div className="flex justify-between items-center mb-2"><h2 className="font-display text-2xl">صندوق الإشعارات</h2><button className="text-sm text-copper" onClick={readAll}>تعليم الكل كمقروء</button></div>
        {inbox.length === 0 ? <p className="text-mute bg-char2 p-6 text-center">لا توجد إشعارات.</p> :
          <ul className="bg-char2 divide-y divide-ivory/15">{inbox.map(i => <li key={i.id} className={`p-3 flex justify-between text-sm ${i.is_read ? 'text-mute' : ''}`}>{i.order_id ? <Link className="hover:text-copper" to={`/admin/orders/${i.order_id}`}>{i.message}</Link> : <span>{i.message}</span>}<span className="text-xs text-mute">{new Date(i.created_at).toLocaleString('ar')}</span></li>)}</ul>}</section>
    </div>
  )
}
