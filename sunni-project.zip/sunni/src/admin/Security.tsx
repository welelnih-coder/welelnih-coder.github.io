import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { supabase } from '../lib/supabase'
import { useAuth } from '../lib/auth'
export default function Security() {
  const { user, mustChange, recovery, refresh } = useAuth(); const nav = useNavigate()
  const [cur, setCur] = useState(''); const [n1, setN1] = useState(''); const [n2, setN2] = useState('')
  const [busy, setBusy] = useState(false); const [msg, setMsg] = useState<{ ok: boolean; t: string } | null>(null)
  const submit = async (e: React.FormEvent) => {
    e.preventDefault(); if (busy) return; setMsg(null)
    if (n1.length < 8) return setMsg({ ok: false, t: 'كلمة المرور الجديدة يجب ألا تقل عن 8 أحرف.' })
    if (n1 === '2281' || n1 === cur) return setMsg({ ok: false, t: 'اختر كلمة مرور مختلفة وأقوى.' })
    if (n1 !== n2) return setMsg({ ok: false, t: 'تأكيد كلمة المرور غير مطابق.' })
    setBusy(true)
    if (!recovery) {
      const { error } = await supabase.auth.signInWithPassword({ email: user!.email!, password: cur })
      if (error) { setBusy(false); return setMsg({ ok: false, t: 'كلمة المرور الحالية غير صحيحة.' }) }
    }
    const { error } = await supabase.auth.updateUser({ password: n1 })
    if (error) { setBusy(false); return setMsg({ ok: false, t: 'تعذّر الحفظ: ' + error.message }) }
    await supabase.rpc('mark_password_changed')
    await refresh(); setBusy(false); setCur(''); setN1(''); setN2('')
    setMsg({ ok: true, t: 'تم تغيير كلمة المرور. القديمة لم تعد صالحة.' })
    if (mustChange || recovery) setTimeout(() => nav('/admin'), 1200)
  }
  return (
    <form onSubmit={submit} className="max-w-sm space-y-3">
      <h1 className="font-display text-3xl mb-1">الأمان وتغيير كلمة المرور</h1>
      {(mustChange || recovery) && <p className="text-sm text-copper">يجب تعيين كلمة مرور جديدة وقوية قبل متابعة الإدارة.</p>}
      {!recovery && <input className="inp" type="password" required dir="ltr" placeholder="كلمة المرور الحالية" value={cur} onChange={e => setCur(e.target.value)} autoComplete="current-password" />}
      <input className="inp" type="password" required dir="ltr" placeholder="كلمة المرور الجديدة" value={n1} onChange={e => setN1(e.target.value)} autoComplete="new-password" />
      <input className="inp" type="password" required dir="ltr" placeholder="تأكيد كلمة المرور الجديدة" value={n2} onChange={e => setN2(e.target.value)} autoComplete="new-password" />
      {msg && <p role="alert" className={`text-sm ${msg.ok ? 'text-copper' : 'text-[#e0a58a]'}`}>{msg.t}</p>}
      <button className="btn" disabled={busy}>{busy ? 'جارٍ الحفظ…' : 'حفظ كلمة المرور'}</button>
    </form>
  )
}
