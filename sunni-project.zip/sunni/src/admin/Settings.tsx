import { useEffect, useState } from 'react'
import { supabase } from '../lib/supabase'
import { publicUrl } from '../lib/util'
import type { Settings } from '../lib/types'
type Slot = 'logo_path' | 'favicon_path' | 'share_image_path' | 'hero_image_path'
const SLOTS: { k: Slot; t: string; accept: string }[] = [
  { k: 'logo_path', t: 'الشعار', accept: 'image/png,image/jpeg,image/webp' },
  { k: 'favicon_path', t: 'أيقونة الموقع (Favicon)', accept: 'image/png,image/x-icon,image/vnd.microsoft.icon' },
  { k: 'share_image_path', t: 'صورة المشاركة', accept: 'image/png,image/jpeg,image/webp' },
  { k: 'hero_image_path', t: 'صورة الصفحة الرئيسية', accept: 'image/png,image/jpeg,image/webp' }]
export default function StoreSettings() {
  const [s, setS] = useState<(Settings & { share_image_path: string | null }) | null>(null)
  const [t, setT] = useState({ phones: '', pay: '', fee: '' })
  const [files, setFiles] = useState<Partial<Record<Slot, File>>>({}); const [sts, setSts] = useState<{ key: string; label: string }[]>([])
  const [busy, setBusy] = useState(false); const [msg, setMsg] = useState<{ ok: boolean; t: string } | null>(null)
  const load = async () => {
    const [a, b] = await Promise.all([supabase.from('store_settings').select('*').eq('id', 1).single(), supabase.from('order_statuses').select('key,label').order('sort_order')])
    if (a.data) { setS(a.data); setT({ phones: a.data.phones.join('\n'), pay: (a.data.payment_methods as string[]).join('\n'), fee: String(a.data.delivery_fee) }) }
    setSts(b.data ?? [])
  }
  useEffect(() => { load() }, [])
  if (!s) return <p className="text-mute">جارٍ التحميل…</p>
  const set = (k: keyof Settings) => (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => setS({ ...s, [k]: e.target.type === 'checkbox' ? (e.target as HTMLInputElement).checked : e.target.value })
  const lines = (v: string) => v.split('\n').map(x => x.trim()).filter(Boolean)
  const save = async (e: React.FormEvent) => {
    e.preventDefault(); if (busy) return; setMsg(null)
    const fee = Number(t.fee); if (!(fee >= 0)) return setMsg({ ok: false, t: 'تكلفة التوصيل غير صالحة.' })
    if (!s.name_ar.trim()) return setMsg({ ok: false, t: 'اسم المتجر مطلوب.' })
    if (!confirm('حفظ التغييرات وتطبيقها على جميع صفحات الموقع؟')) return
    setBusy(true)
    try {
      const paths: Partial<Record<Slot, string>> = {}
      for (const { k } of SLOTS) { const f = files[k]; if (!f) continue
        const ext = (f.name.split('.').pop() || 'png').toLowerCase().replace(/[^a-z0-9]/g, '')
        const path = `${k.replace('_path', '')}/${crypto.randomUUID()}.${ext}`
        const up = await supabase.storage.from('store-assets').upload(path, f, { contentType: f.type, cacheControl: '31536000' }); if (up.error) throw up.error; paths[k] = path }
      const { error } = await supabase.from('store_settings').update({
        name_ar: s.name_ar.trim(), name_en: s.name_en.trim(), description: s.description || null, hero_title: s.hero_title || null, hero_text: s.hero_text || null,
        phones: lines(t.phones), city: s.city || null, delivery_info: s.delivery_info || null, delivery_fee: fee, currency: s.currency.trim() || 'MRU',
        payment_methods: lines(t.pay), maintenance_mode: s.maintenance_mode, ...paths }).eq('id', 1)
      if (error) throw error
      for (const x of sts) { const { error: e2 } = await supabase.from('order_statuses').update({ label: x.label.trim() || x.key }).eq('key', x.key); if (e2) throw e2 }
      setFiles({}); await load(); setMsg({ ok: true, t: 'تم الحفظ. أعد تحميل صفحات المتجر لرؤية التغييرات.' })
    } catch { setMsg({ ok: false, t: 'تعذّر الحفظ. تحقق من الاتصال وحجم الصور.' }) }
    setBusy(false)
  }
  const prev = (k: Slot) => files[k] ? URL.createObjectURL(files[k]!) : publicUrl('store-assets', s[k])
  return (
    <form onSubmit={save} className="max-w-xl space-y-3">
      <h1 className="font-display text-3xl mb-2">إعدادات المتجر</h1>
      <div className="grid grid-cols-2 gap-3"><input className="inp" placeholder="اسم المتجر" value={s.name_ar} onChange={set('name_ar')} /><input className="inp" dir="ltr" placeholder="الاسم اللاتيني" value={s.name_en} onChange={set('name_en')} /></div>
      <textarea className="inp" rows={2} placeholder="وصف المتجر" value={s.description ?? ''} onChange={set('description')} />
      <input className="inp" placeholder="العنوان الرئيسي للصفحة الرئيسية" value={s.hero_title ?? ''} onChange={set('hero_title')} />
      <textarea className="inp" rows={2} placeholder="النص الرئيسي (بلا ادعاءات غير مؤكدة)" value={s.hero_text ?? ''} onChange={set('hero_text')} />
      <section className="bg-char2 p-4 space-y-3"><h2 className="text-sm text-copper">الشعار والصور — معاينة قبل الحفظ</h2>
        {SLOTS.map(({ k, t: title, accept }) => (
          <div key={k} className="flex gap-3 items-center"><div className="w-20 h-20 bg-brown/40 shrink-0 grid place-items-center text-xs text-mute">{prev(k) ? <img src={prev(k)!} alt="" className="max-w-full max-h-full object-contain" /> : 'لا توجد'}</div>
            <div className="text-sm"><p className="mb-1">{title}{files[k] && <span className="text-copper"> (جديدة — لم تُحفظ)</span>}</p><input type="file" accept={accept} onChange={e => { const f = e.target.files?.[0]; setFiles(v => ({ ...v, [k]: f })) }} /></div></div>))}
      </section>
      <input className="inp" placeholder="المدينة" value={s.city ?? ''} onChange={set('city')} />
      <textarea className="inp" rows={2} dir="ltr" placeholder="أرقام التواصل (رقم في كل سطر)" value={t.phones} onChange={e => setT({ ...t, phones: e.target.value })} />
      <textarea className="inp" rows={2} placeholder="معلومات التوصيل" value={s.delivery_info ?? ''} onChange={set('delivery_info')} />
      <div className="grid grid-cols-2 gap-3"><input className="inp" type="number" min="0" step="0.01" placeholder="تكلفة التوصيل" value={t.fee} onChange={e => setT({ ...t, fee: e.target.value })} /><input className="inp" dir="ltr" placeholder="العملة" value={s.currency} onChange={set('currency')} /></div>
      <textarea className="inp" rows={2} placeholder="وسائل الدفع المتاحة (واحدة في كل سطر، مثل: الدفع عند الاستلام)" value={t.pay} onChange={e => setT({ ...t, pay: e.target.value })} />
      <section className="bg-char2 p-4 space-y-2"><h2 className="text-sm text-copper">أسماء حالات الطلب</h2>{sts.map((x, i) => <input key={x.key} className="inp" value={x.label} onChange={e => setSts(sts.map((y, j) => j === i ? { ...y, label: e.target.value } : y))} aria-label={x.key} />)}</section>
      <label className="flex gap-2 text-sm"><input type="checkbox" checked={s.maintenance_mode} onChange={set('maintenance_mode')} />وضع الصيانة (يغلق المتجر أمام الزوار)</label>
      {msg && <p role="alert" className={`text-sm ${msg.ok ? 'text-copper' : 'text-[#e0a58a]'}`}>{msg.t}</p>}
      <button className="btn" disabled={busy}>{busy ? 'جارٍ الحفظ…' : 'حفظ الإعدادات'}</button>
    </form>
  )
}
