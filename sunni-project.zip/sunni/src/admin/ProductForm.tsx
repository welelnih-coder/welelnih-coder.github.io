import { useEffect, useState } from 'react'
import { useNavigate, useParams } from 'react-router-dom'
import { supabase } from '../lib/supabase'
import { publicUrl } from '../lib/util'
import type { Category } from '../lib/types'
type Img = { id: string; path: string; is_main: boolean }
const empty = { name: '', description: '', price: '', compare_at_price: '', category_id: '', stock: '0', size_info: '', is_available: true, is_published: false, is_featured: false, sort_order: '0' }

async function toWebp(file: File, max = 1600): Promise<Blob> {
  const bmp = await createImageBitmap(file)
  const r = Math.min(1, max / Math.max(bmp.width, bmp.height))
  const c = document.createElement('canvas'); c.width = Math.round(bmp.width * r); c.height = Math.round(bmp.height * r)
  c.getContext('2d')!.drawImage(bmp, 0, 0, c.width, c.height)
  return new Promise((res, rej) => c.toBlob(b => b ? res(b) : rej(new Error('image')), 'image/webp', 0.85))
}

export default function ProductForm() {
  const { id } = useParams(); const nav = useNavigate(); const editing = !!id
  const [f, setF] = useState(empty); const [cats, setCats] = useState<Category[]>([]); const [imgs, setImgs] = useState<Img[]>([]); const [files, setFiles] = useState<File[]>([])
  const [busy, setBusy] = useState(false); const [err, setErr] = useState(''); const [loading, setLoading] = useState(editing)
  const load = async () => {
    const { data } = await supabase.from('products').select('*, product_images(id,path,is_main,sort_order)').eq('id', id!).maybeSingle()
    if (data) { setF({ name: data.name, description: data.description ?? '', price: String(data.price), compare_at_price: data.compare_at_price == null ? '' : String(data.compare_at_price), category_id: data.category_id ?? '', stock: String(data.stock), size_info: data.size_info ?? '', is_available: data.is_available, is_published: data.is_published, is_featured: data.is_featured, sort_order: String(data.sort_order) }); setImgs(data.product_images) }
    setLoading(false)
  }
  useEffect(() => { supabase.from('categories').select('*').order('sort_order').then(r => setCats((r.data ?? []) as Category[])); if (editing) load() }, [id])
  const set = (k: keyof typeof empty) => (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) =>
    setF({ ...f, [k]: e.target.type === 'checkbox' ? (e.target as HTMLInputElement).checked : e.target.value })

  const save = async (e: React.FormEvent) => {
    e.preventDefault(); if (busy) return; setErr('')
    const price = Number(f.price); const cmp = f.compare_at_price === '' ? null : Number(f.compare_at_price); const stock = parseInt(f.stock, 10)
    if (!f.name.trim()) return setErr('أدخل اسم العطر.')
    if (!(price >= 0) || f.price === '') return setErr('السعر غير صالح.')
    if (cmp !== null && !(cmp > price)) return setErr('السعر السابق يجب أن يكون أعلى من السعر الحالي.')
    if (!(stock >= 0)) return setErr('الكمية غير صالحة.')
    setBusy(true)
    try {
      const row = { name: f.name.trim(), description: f.description.trim() || null, price, compare_at_price: cmp, category_id: f.category_id || null, stock, size_info: f.size_info.trim() || null, is_available: f.is_available, is_published: f.is_published, is_featured: f.is_featured, sort_order: parseInt(f.sort_order, 10) || 0 }
      let pid = id
      if (editing) { const { error } = await supabase.from('products').update(row).eq('id', id!); if (error) throw error }
      else { const { data, error } = await supabase.from('products').insert(row).select('id').single(); if (error) throw error; pid = data.id }
      let hasMain = imgs.some(i => i.is_main)
      for (const file of files) {
        const blob = await toWebp(file); const ext = blob.type === 'image/webp' ? 'webp' : 'png'
        const path = `${pid}/${crypto.randomUUID()}.${ext}`
        const up = await supabase.storage.from('product-images').upload(path, blob, { contentType: blob.type, cacheControl: '31536000' }); if (up.error) throw up.error
        const { error } = await supabase.from('product_images').insert({ product_id: pid, path, is_main: !hasMain }); if (error) throw error
        hasMain = true
      }
      nav('/admin/products')
    } catch { setErr('تعذّر الحفظ. تحقق من الاتصال وحاول مجددًا.'); setBusy(false) }
  }
  const delImg = async (i: Img) => { if (!confirm('حذف هذه الصورة؟')) return; await supabase.storage.from('product-images').remove([i.path]); await supabase.from('product_images').delete().eq('id', i.id); load() }
  const mainImg = async (i: Img) => { await supabase.from('product_images').update({ is_main: false }).eq('product_id', id!); await supabase.from('product_images').update({ is_main: true }).eq('id', i.id); load() }

  if (loading) return <p className="text-mute">جارٍ التحميل…</p>
  return (
    <form onSubmit={save} className="max-w-xl space-y-3">
      <h1 className="font-display text-3xl mb-2">{editing ? 'تعديل المنتج' : 'إضافة منتج'}</h1>
      <input className="inp" required placeholder="اسم العطر" value={f.name} onChange={set('name')} />
      <textarea className="inp" rows={4} placeholder="وصف المنتج (لا تكتب ادعاءات لم تتأكد منها)" value={f.description} onChange={set('description')} />
      <div className="grid grid-cols-2 gap-3">
        <input className="inp" required type="number" min="0" step="0.01" inputMode="decimal" placeholder="السعر (MRU)" value={f.price} onChange={set('price')} />
        <input className="inp" type="number" min="0" step="0.01" inputMode="decimal" placeholder="السعر السابق (اختياري)" value={f.compare_at_price} onChange={set('compare_at_price')} />
        <input className="inp" required type="number" min="0" step="1" inputMode="numeric" placeholder="الكمية المتاحة" value={f.stock} onChange={set('stock')} />
        <input className="inp" placeholder="الحجم / السعة (مثال: 100 مل)" value={f.size_info} onChange={set('size_info')} />
      </div>
      <select className="inp" value={f.category_id} onChange={set('category_id')}><option value="">بلا تصنيف</option>{cats.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}</select>
      <input className="inp" type="number" step="1" placeholder="ترتيب العرض (رقم أصغر = أولًا)" value={f.sort_order} onChange={set('sort_order')} />
      <div className="flex flex-wrap gap-5 text-sm">
        <label className="flex gap-2"><input type="checkbox" checked={f.is_available} onChange={set('is_available')} />متوفر</label>
        <label className="flex gap-2"><input type="checkbox" checked={f.is_published} onChange={set('is_published')} />منشور (يظهر للزوار)</label>
        <label className="flex gap-2"><input type="checkbox" checked={f.is_featured} onChange={set('is_featured')} />منتج مميز</label>
      </div>
      <div>
        <p className="text-sm mb-2">الصور</p>
        {imgs.length > 0 && <div className="flex flex-wrap gap-3 mb-3">{imgs.map(i => (
          <div key={i.id} className="w-24"><div className={`h-28 bg-brown/40 border ${i.is_main ? 'border-copper' : 'border-transparent'}`}><img src={publicUrl('product-images', i.path)!} alt="" className="w-full h-full object-contain" /></div>
            <div className="flex justify-between text-xs mt-1">{i.is_main ? <span className="text-copper">رئيسية</span> : <button type="button" onClick={() => mainImg(i)}>رئيسية</button>}<button type="button" onClick={() => delImg(i)}>حذف</button></div></div>))}</div>}
        <input type="file" accept="image/jpeg,image/png,image/webp" multiple className="text-sm" onChange={e => setFiles(Array.from(e.target.files ?? []))} />
        {files.length > 0 && <p className="text-xs text-mute mt-1">ستُضغط {files.length} صورة وتُرفع عند الحفظ. أول صورة تصبح رئيسية إن لم توجد رئيسية.</p>}
      </div>
      {err && <p role="alert" className="text-sm text-[#e0a58a]">{err}</p>}
      <button className="btn" disabled={busy}>{busy ? 'جارٍ الحفظ…' : 'حفظ المنتج'}</button>
    </form>
  )
}
