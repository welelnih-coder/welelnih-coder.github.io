import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { supabase } from '../lib/supabase'
import { money } from '../lib/util'
type O = { id: string; order_number: number; customer_name: string; total: number; currency: string; status: string; created_at: string }
const cnt = (q: PromiseLike<{ count: number | null }>) => q.then(r => r.count ?? 0)
export default function Dashboard() {
  const [d, setD] = useState<{ pub: number; out: number; nw: number; prep: number; done: number; sum: number; cur: string; latest: O[]; labels: Record<string, string> } | null>(null); const [err, setErr] = useState(false)
  useEffect(() => {
    const head = { count: 'exact' as const, head: true }
    Promise.all([
      cnt(supabase.from('products').select('id', head).eq('is_published', true)),
      cnt(supabase.from('products').select('id', head).eq('is_published', true).or('is_available.eq.false,stock.eq.0')),
      cnt(supabase.from('orders').select('id', head).eq('status', 'new')),
      cnt(supabase.from('orders').select('id', head).eq('status', 'preparing')),
      cnt(supabase.from('orders').select('id', head).eq('status', 'completed')),
      supabase.from('orders').select('total,currency').neq('status', 'cancelled'),
      supabase.from('orders').select('id,order_number,customer_name,total,currency,status,created_at').order('created_at', { ascending: false }).limit(6),
      supabase.from('order_statuses').select('key,label'),
    ]).then(([pub, out, nw, prep, done, all, latest, st]) => {
      const rows = (all.data ?? []) as { total: number; currency: string }[]
      setD({ pub, out, nw, prep, done, sum: rows.reduce((a, r) => a + Number(r.total), 0), cur: rows[0]?.currency ?? 'MRU', latest: (latest.data ?? []) as O[], labels: Object.fromEntries((st.data ?? []).map(s => [s.key, s.label])) })
    }).catch(() => setErr(true))
  }, [])
  if (err) return <p className="text-mute">تعذّر تحميل البيانات.</p>
  if (!d) return <p className="text-mute">جارٍ التحميل…</p>
  const box = (t: string, v: string | number) => <div className="bg-char2 p-4"><p className="text-xs text-mute">{t}</p><p className="text-2xl mt-1">{v}</p></div>
  return (
    <div>
      <h1 className="font-display text-3xl mb-5">لوحة المعلومات</h1>
      <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 mb-3">
        {box('منتجات منشورة', d.pub)}{box('منشورة وغير متوفرة', d.out)}{box('طلبات جديدة', d.nw)}{box('قيد التجهيز', d.prep)}{box('مكتملة', d.done)}{box('قيمة الطلبات (غير الملغاة)', money(d.sum, d.cur))}
      </div>
      <h2 className="font-display text-2xl mt-8 mb-3">أحدث الطلبات</h2>
      {d.latest.length === 0 ? <p className="text-mute bg-char2 p-6 text-center">لا توجد طلبات بعد.</p> :
        <ul className="bg-char2 divide-y divide-ivory/15">{d.latest.map(o => <li key={o.id}><Link to={`/admin/orders/${o.id}`} className="p-3 flex justify-between gap-3 hover:bg-brown/30"><span>#{o.order_number} · {o.customer_name}</span><span className="text-sm text-mute">{d.labels[o.status] ?? o.status} · {money(o.total, o.currency)}</span></Link></li>)}</ul>}
    </div>
  )
}
