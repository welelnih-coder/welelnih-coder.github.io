import { useEffect, useState } from 'react'
import { supabase } from '../lib/supabase'
import type { Category } from '../lib/types'
export default function Categories() {
  const [list, setList] = useState<Category[]>([]); const [name, setName] = useState(''); const [err, setErr] = useState(''); const [busy, setBusy] = useState(false)
  const load = () => supabase.from('categories').select('*').order('sort_order').then(r => setList((r.data ?? []) as Category[]))
  useEffect(() => { load() }, [])
  const add = async (e: React.FormEvent) => {
    e.preventDefault(); if (busy || !name.trim()) return; setBusy(true); setErr('')
    const slug = name.trim().replace(/\s+/g, '-') + '-' + Math.random().toString(36).slice(2, 6)
    const { error } = await supabase.from('categories').insert({ name: name.trim(), slug, sort_order: list.length })
    setBusy(false); if (error) setErr('تعذّر الحفظ.'); else { setName(''); load() }
  }
  const rename = async (c: Category) => { const n = prompt('الاسم الجديد', c.name)?.trim(); if (!n) return; const { error } = await supabase.from('categories').update({ name: n }).eq('id', c.id); error ? setErr('تعذّر التعديل.') : load() }
  const del = async (c: Category) => { if (!confirm(`حذف التصنيف «${c.name}»؟ ستبقى منتجاته بلا تصنيف.`)) return; const { error } = await supabase.from('categories').delete().eq('id', c.id); error ? setErr('تعذّر الحذف.') : load() }
  return (
    <div className="max-w-lg">
      <h1 className="font-display text-3xl mb-5">التصنيفات</h1>
      <form onSubmit={add} className="flex gap-2 mb-4"><input className="inp" placeholder="اسم تصنيف جديد" value={name} onChange={e => setName(e.target.value)} /><button className="btn whitespace-nowrap" disabled={busy}>إضافة</button></form>
      {err && <p role="alert" className="text-sm text-[#e0a58a] mb-3">{err}</p>}
      {list.length === 0 ? <p className="text-mute">لا توجد تصنيفات بعد.</p> :
        <ul className="bg-char2 divide-y divide-ivory/15">{list.map(c => <li key={c.id} className="p-3 flex items-center gap-3"><span className="flex-1">{c.name}</span><button className="text-sm text-copper" onClick={() => rename(c)}>تعديل</button><button className="text-sm text-mute hover:text-ivory" onClick={() => del(c)}>حذف</button></li>)}</ul>}
    </div>
  )
}
