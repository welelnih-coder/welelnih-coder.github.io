import { useEffect, useState } from 'react'
import { NavLink, Navigate, Outlet, useLocation } from 'react-router-dom'
import { AuthProvider, useAuth } from '../lib/auth'
import { supabase } from '../lib/supabase'
export default function AdminRoot() {
  useEffect(() => { const m = document.createElement('meta'); m.name = 'robots'; m.content = 'noindex'; document.head.appendChild(m); return () => m.remove() }, [])
  return <AuthProvider><Guard /></AuthProvider>
}
function Guard() {
  const { loading, user, isAdmin, mustChange, recovery } = useAuth(); const loc = useLocation()
  const onLogin = loc.pathname === '/admin/login'
  if (loading) return <p className="text-center text-mute py-24">جارٍ التحميل…</p>
  if (onLogin) return <Outlet />
  if (!user) return <Navigate to="/admin/login" replace />
  if (!isAdmin) return <div className="text-center py-24"><p className="mb-4">هذا الحساب لا يملك صلاحية الإدارة.</p><button className="btn btn-o" onClick={() => supabase.auth.signOut()}>تسجيل الخروج</button></div>
  if ((mustChange || recovery) && loc.pathname !== '/admin/security') return <Navigate to="/admin/security" replace />
  const lock = mustChange || recovery
  const link = 'px-3 py-2 text-sm whitespace-nowrap hover:text-copper'
  const act = ({ isActive }: { isActive: boolean }) => link + (isActive ? ' text-copper' : '')
  return (
    <div className="min-h-screen md:flex">
      <nav className="md:w-56 md:min-h-screen bg-[#171413] border-b md:border-b-0 md:border-s border-ivory/15 p-3 flex md:flex-col gap-1 overflow-x-auto pt-[max(12px,env(safe-area-inset-top))]" aria-label="لوحة التحكم">
        <span className="font-display text-2xl px-3 py-2 hidden md:block">لوحة سُنّي</span>
        {!lock && <><NavLink to="/admin" end className={act}>لوحة المعلومات</NavLink><NavLink to="/admin/orders" className={act}>إدارة الطلبات</NavLink><NavLink to="/admin/products" end className={act}>إدارة المنتجات</NavLink><NavLink to="/admin/products/new" className={act}>إضافة منتج</NavLink><NavLink to="/admin/categories" className={act}>إدارة التصنيفات</NavLink><NavLink to="/admin/settings" className={act}>إعدادات المتجر</NavLink><NavLink to="/admin/pages" className={act}>صفحات الموقع</NavLink><NavLink to="/admin/notifications" className={act}>التنبيهات<InboxBadge /></NavLink></>}
        <NavLink to="/admin/security" className={act}>الأمان وكلمة المرور</NavLink>
        <button className={link + ' text-start md:mt-auto'} onClick={() => supabase.auth.signOut().then(() => location.assign('/admin/login'))}>تسجيل الخروج</button>
      </nav>
      <main className="flex-1 p-5 md:p-8 max-w-4xl"><Outlet /></main>
    </div>
  )
}

function InboxBadge() {
  const [n, setN] = useState(0)
  useEffect(() => {
    const load = () => supabase.from('admin_inbox').select('id', { count: 'exact', head: true }).eq('is_read', false).then(r => setN(r.count ?? 0))
    load()
    const ch = supabase.channel('inbox').on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'admin_inbox' }, p => {
      load(); if (typeof Notification !== 'undefined' && Notification.permission === 'granted') new Notification('سُنّي', { body: (p.new as { message: string }).message })
    }).subscribe()
    return () => { supabase.removeChannel(ch) }
  }, [])
  return n > 0 ? <span className="ms-1 bg-copper text-char text-[11px] rounded-full px-1.5">{n}</span> : null
}
