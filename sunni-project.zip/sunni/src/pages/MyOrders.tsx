import { Link } from 'react-router-dom'
export default function MyOrders() {
  let list: { n: number; t: string; at: number }[] = []
  try { list = JSON.parse(localStorage.getItem('sunni_orders') || '[]') } catch { /* ignore */ }
  return (
    <div className="max-w-xl mx-auto px-5 py-12">
      <h1 className="font-display text-4xl mb-6">طلباتي</h1>
      {list.length === 0 ? <p className="text-mute">لا توجد طلبات محفوظة على هذا الجهاز.</p>
        : <ul className="bg-char2 divide-y divide-ivory/15">{list.map(o => <li key={o.n}><Link className="p-4 flex justify-between hover:bg-brown/30" to={`/order/${o.n}?t=${o.t}`}><span>طلب رقم {o.n}</span><span className="text-mute text-sm">{new Date(o.at).toLocaleDateString('ar')}</span></Link></li>)}</ul>}
      <p className="text-xs text-mute mt-4">تظهر هنا الطلبات التي أُرسلت من هذا الجهاز فقط.</p>
    </div>
  )
}
