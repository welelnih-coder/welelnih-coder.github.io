import { useEffect, useRef, useState } from 'react'
import { useSearchParams, Link } from 'react-router-dom'
import { supabase } from '../lib/supabase'
import { PRODUCT_SELECT } from '../lib/util'
import type { Category, Product } from '../lib/types'
import ProductCard from '../components/ProductCard'
export default function Shop() {
  const [sp, setSp] = useSearchParams()
  const q = sp.get('q') ?? ''; const cat = sp.get('cat') ?? ''; const sort = sp.get('sort') ?? 'new'
  const onlyIn = sp.get('in') === '1'; const offers = sp.get('offers') === '1'; const max = sp.get('max') ?? ''
  const [cats, setCats] = useState<Category[]>([]); const [items, setItems] = useState<Product[]>([])
  const [loading, setLoading] = useState(true); const [err, setErr] = useState(false)
  const input = useRef<HTMLInputElement>(null)
  const set = (k: string, v: string) => { const n = new URLSearchParams(sp); v ? n.set(k, v) : n.delete(k); n.delete('focus'); setSp(n, { replace: true }) }
  useEffect(() => { supabase.from('categories').select('*').order('sort_order').then(r => setCats((r.data ?? []) as Category[])); if (sp.get('focus')) input.current?.focus() }, [])
  useEffect(() => {
    setLoading(true); setErr(false)
    const t = setTimeout(async () => {
      let qb = supabase.from('products').select(PRODUCT_SELECT).eq('is_published', true)
      const term = q.replace(/[%,()]/g, ' ').trim()
      if (term) qb = qb.or(`name.ilike.%${term}%,description.ilike.%${term}%`)
      const c = cats.find(x => x.slug === cat); if (cat && c) qb = qb.eq('category_id', c.id)
      if (onlyIn) qb = qb.eq('is_available', true).gt('stock', 0)
      if (offers) qb = qb.not('compare_at_price', 'is', null)
      if (max && Number(max) > 0) qb = qb.lte('price', Number(max))
      qb = sort === 'asc' ? qb.order('price', { ascending: true }) : sort === 'desc' ? qb.order('price', { ascending: false }) : qb.order('created_at', { ascending: false })
      const { data, error } = await qb
      if (error) setErr(true); else setItems((data ?? []) as Product[])
      setLoading(false)
    }, 250)
    return () => clearTimeout(t)
  }, [q, cat, sort, onlyIn, offers, max, cats])
  return (
    <div className="max-w-6xl mx-auto px-5 py-10">
      <h1 className="font-display text-4xl mb-6">العطور</h1>
      <div className="grid gap-3 sm:grid-cols-[2fr_1fr_1fr_1fr] mb-4">
        <input ref={input} className="inp" type="search" placeholder="ابحث بالاسم أو الوصف" value={q} onChange={e => set('q', e.target.value)} aria-label="بحث" />
        <select className="inp" value={cat} onChange={e => set('cat', e.target.value)} aria-label="التصنيف"><option value="">كل التصنيفات</option>{cats.map(c => <option key={c.id} value={c.slug}>{c.name}</option>)}</select>
        <select className="inp" value={sort} onChange={e => set('sort', e.target.value)} aria-label="الترتيب"><option value="new">الأحدث</option><option value="asc">السعر: من الأقل</option><option value="desc">السعر: من الأعلى</option></select>
        <input className="inp" type="number" min="0" inputMode="numeric" placeholder="أعلى سعر" value={max} onChange={e => set('max', e.target.value)} aria-label="أعلى سعر" />
      </div>
      <div className="flex gap-5 text-sm mb-8">
        <label className="flex gap-2 items-center"><input type="checkbox" checked={onlyIn} onChange={e => set('in', e.target.checked ? '1' : '')} />المتوفر فقط</label>
        <label className="flex gap-2 items-center"><input type="checkbox" checked={offers} onChange={e => set('offers', e.target.checked ? '1' : '')} />العروض</label>
      </div>
      {err ? <p className="text-center text-mute py-16">حدث خطأ أثناء التحميل. حاول مجددًا.</p>
        : loading ? <p className="text-center text-mute py-16">جارٍ التحميل…</p>
        : items.length === 0 ? <div className="bg-char2 text-center py-14"><p className="text-mute mb-5">لا توجد نتائج مطابقة.</p><Link to="/shop" className="btn btn-o" onClick={() => setSp({})}>عرض جميع المنتجات</Link></div>
        : <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6">{items.map(p => <ProductCard key={p.id} p={p} />)}</div>}
    </div>
  )
}
