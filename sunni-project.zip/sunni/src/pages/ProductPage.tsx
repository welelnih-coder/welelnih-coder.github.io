import { useEffect, useState } from 'react'
import { useParams, Link } from 'react-router-dom'
import { supabase } from '../lib/supabase'
import { useCart } from '../lib/cart'
import { useSettings } from '../lib/settings'
import { PRODUCT_SELECT, inStock, money, publicUrl } from '../lib/util'
import type { Product } from '../lib/types'
export default function ProductPage() {
  const { id } = useParams(); const { add } = useCart(); const { settings } = useSettings()
  const [p, setP] = useState<Product | null>(null); const [state, setState] = useState<'load' | 'ok' | 'none'>('load'); const [sel, setSel] = useState(0)
  useEffect(() => {
    supabase.from('products').select(PRODUCT_SELECT).eq('id', id!).eq('is_published', true).maybeSingle()
      .then(r => { if (r.data) { setP(r.data as Product); setState('ok') } else setState('none') })
  }, [id])
  if (state === 'load') return <p className="text-center text-mute py-24">جارٍ التحميل…</p>
  if (!p) return <div className="text-center py-24"><p className="text-mute mb-5">المنتج غير موجود.</p><Link className="btn btn-o" to="/shop">العودة إلى العطور</Link></div>
  const imgs = [...p.product_images].sort((a, b) => Number(b.is_main) - Number(a.is_main) || a.sort_order - b.sort_order)
  const ok = inStock(p); const cur = settings?.currency
  return (
    <div className="max-w-6xl mx-auto px-5 py-10 grid md:grid-cols-2 gap-10">
      <div>
        <div className="aspect-[4/5] bg-brown/40">{imgs[sel] ? <img src={publicUrl('product-images', imgs[sel].path)!} alt={p.name} className="w-full h-full object-contain" /> : <div className="h-full grid place-items-center text-mute">بلا صورة</div>}</div>
        {imgs.length > 1 && <div className="flex gap-2 mt-3 overflow-x-auto">{imgs.map((im, i) => <button key={im.path} onClick={() => setSel(i)} aria-label={`صورة ${i + 1}`} className={`w-16 h-20 shrink-0 bg-brown/40 border ${i === sel ? 'border-copper' : 'border-transparent'}`}><img src={publicUrl('product-images', im.path)!} alt="" loading="lazy" className="w-full h-full object-contain" /></button>)}</div>}
      </div>
      <div>
        <h1 className="font-display text-4xl mb-3">{p.name}</h1>
        <div className="flex items-baseline gap-3 text-xl mb-2">{money(p.price, cur)}{p.compare_at_price && <s className="text-mute text-base">{money(p.compare_at_price, cur)}</s>}</div>
        <p className={`text-sm mb-5 ${ok ? 'text-copper' : 'text-mute'}`}>{ok ? 'متوفر' : 'غير متوفر'}</p>
        {p.size_info && <p className="text-sm text-mute mb-3">الحجم: {p.size_info}</p>}
        {p.description && <p className="text-ivory/80 whitespace-pre-line mb-8">{p.description}</p>}
        <button className="btn" disabled={!ok} onClick={() => add(p)}>أضف إلى السلة</button>
      </div>
    </div>
  )
}
