import { useRef, useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { supabase } from '../lib/supabase'
import { useCart } from '../lib/cart'
import { useSettings } from '../lib/settings'
import { money } from '../lib/util'

const errText = (m: string) =>
  m.includes('insufficient_stock') ? 'الكمية المطلوبة من أحد المنتجات لم تعد متوفرة. عدّل السلة ثم أعد المحاولة.'
  : m.includes('product_unavailable') ? 'أحد المنتجات لم يعد متوفرًا. احذفه من السلة وأعد المحاولة.'
  : m.includes('too_many_requests') ? 'محاولات كثيرة خلال وقت قصير. حاول لاحقًا.'
  : m.includes('store_closed') ? 'المتجر مغلق مؤقتًا.'
  : m.includes('invalid_input') ? 'تحقق من الاسم ورقم الهاتف والمدينة.'
  : /fetch|network/i.test(m) ? 'تعذّر الاتصال بالإنترنت. لم يُرسل الطلب.'
  : 'تعذّر إرسال الطلب. حاول مجددًا.'

export default function CartPage() {
  const { lines, subtotal, setQty, remove, clear } = useCart(); const { settings } = useSettings(); const nav = useNavigate()
  const key = useRef(crypto.randomUUID() + crypto.randomUUID())
  const [f, setF] = useState({ name: '', phone: '', city: settings?.city ?? '', address: '', notes: '' })
  const [busy, setBusy] = useState(false); const [err, setErr] = useState('')
  const cur = settings?.currency; const fee = Number(settings?.delivery_fee ?? 0)
  const up = (k: keyof typeof f) => (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => setF({ ...f, [k]: e.target.value })

  if (lines.length === 0) return <div className="text-center py-24"><p className="text-mute mb-5">سلتك فارغة.</p><Link to="/shop" className="btn">تصفح العطور</Link></div>

  const submit = async (e: React.FormEvent) => {
    e.preventDefault(); if (busy) return
    if (!f.name.trim() || !f.city.trim()) return setErr('أدخل الاسم والمدينة.')
    if (!/^[0-9+ ]{6,20}$/.test(f.phone)) return setErr('رقم الهاتف غير صالح (أرقام فقط).')
    setBusy(true); setErr('')
    try {
      const { data, error } = await supabase.rpc('create_order', {
        p_name: f.name, p_phone: f.phone, p_city: f.city, p_address: f.address, p_notes: f.notes,
        p_items: lines.map(l => ({ product_id: l.id, qty: l.qty })), p_key: key.current,
      })
      if (error) throw new Error(error.message)
      try { const o = JSON.parse(localStorage.getItem('sunni_orders') || '[]'); o.unshift({ n: data.order_number, t: data.token, at: Date.now() }); localStorage.setItem('sunni_orders', JSON.stringify(o.slice(0, 30))) } catch { /* ignore */ }
      clear(); nav(`/order/${data.order_number}?t=${data.token}`, { replace: true })
    } catch (ex) { setErr(errText(String((ex as Error).message))); setBusy(false) }
  }

  return (
    <div className="max-w-6xl mx-auto px-5 py-10 grid lg:grid-cols-[1.2fr_1fr] gap-10">
      <section>
        <h1 className="font-display text-4xl mb-6">السلة</h1>
        <ul className="divide-y divide-ivory/15">
          {lines.map(l => (
            <li key={l.id} className="py-4 flex gap-4">
              <div className="w-20 h-24 bg-brown/40 shrink-0">{l.image && <img src={l.image} alt="" className="w-full h-full object-contain" />}</div>
              <div className="flex-1">
                <p className="font-medium">{l.name}</p><p className="text-sm text-mute">{money(l.price, cur)}</p>
                <div className="flex items-center gap-3 mt-2">
                  <button className="w-9 h-9 border border-ivory/15" aria-label="تقليل" onClick={() => setQty(l.id, l.qty - 1)}>−</button>
                  <span aria-live="polite">{l.qty}</span>
                  <button className="w-9 h-9 border border-ivory/15" aria-label="زيادة" disabled={l.qty >= l.stock} onClick={() => setQty(l.id, l.qty + 1)}>+</button>
                  <button className="text-sm text-mute ms-auto hover:text-ivory" onClick={() => confirm('حذف المنتج من السلة؟') && remove(l.id)}>حذف</button>
                </div>
              </div>
              <p className="whitespace-nowrap">{money(l.price * l.qty, cur)}</p>
            </li>
          ))}
        </ul>
        <Link to="/shop" className="inline-block mt-6 text-copper text-sm">متابعة التسوق</Link>
      </section>
      <form onSubmit={submit} className="bg-char2 p-6 space-y-3 self-start">
        <h2 className="font-display text-2xl mb-2">إتمام الطلب</h2>
        <input className="inp" required placeholder="الاسم الكامل" value={f.name} onChange={up('name')} autoComplete="name" />
        <input className="inp" required placeholder="رقم الهاتف" inputMode="tel" dir="ltr" value={f.phone} onChange={up('phone')} autoComplete="tel" />
        <input className="inp" required placeholder="المدينة" value={f.city} onChange={up('city')} />
        <input className="inp" placeholder="الحي أو العنوان التفصيلي" value={f.address} onChange={up('address')} />
        <textarea className="inp" rows={2} placeholder="ملاحظات (اختياري)" value={f.notes} onChange={up('notes')} />
        <dl className="text-sm pt-3 space-y-1">
          <div className="flex justify-between"><dt>المجموع</dt><dd>{money(subtotal, cur)}</dd></div>
          <div className="flex justify-between"><dt>التوصيل</dt><dd>{fee > 0 ? money(fee, cur) : 'غير محدد / مجاني'}</dd></div>
          <div className="flex justify-between text-base font-medium border-t border-ivory/15 pt-2"><dt>المبلغ النهائي</dt><dd>{money(subtotal + fee, cur)}</dd></div>
        </dl>
        {settings && settings.payment_methods.length > 0 && <p className="text-xs text-mute">طريقة الدفع: {settings.payment_methods.join('، ')}</p>}
        {err && <p role="alert" className="text-sm text-[#e0a58a]">{err}</p>}
        <button className="btn w-full" disabled={busy}>{busy ? 'جارٍ إرسال الطلب…' : 'تأكيد الطلب'}</button>
        <p className="text-xs text-mute">لا يوجد دفع إلكتروني الآن.</p>
      </form>
    </div>
  )
}
