import { useEffect, useState } from 'react'
import { useParams, useSearchParams, Link } from 'react-router-dom'
import { supabase } from '../lib/supabase'
import { money } from '../lib/util'
type O = { order_number: number; status: string; label: string; total: number; currency: string; created_at: string; updated_at: string; items: { name: string; qty: number; price: number }[] }
export default function OrderPage() {
  const { number } = useParams(); const [sp] = useSearchParams(); const token = sp.get('t')
  const [o, setO] = useState<O | null>(null); const [st, setSt] = useState<'load' | 'ok' | 'none' | 'err'>('load')
  useEffect(() => {
    let live = true
    const load = async () => {
      const { data, error } = await supabase.rpc('get_order_status', { p_number: Number(number), p_token: token })
      if (!live) return
      if (error) return setSt('err'); if (!data) return setSt('none'); setO(data as O); setSt('ok')
    }
    load(); const id = setInterval(load, 30000); return () => { live = false; clearInterval(id) }
  }, [number, token])
  if (st === 'load') return <p className="text-center text-mute py-24">جارٍ التحميل…</p>
  if (st === 'err') return <p className="text-center text-mute py-24">تعذّر تحميل الطلب. حاول لاحقًا.</p>
  if (!o) return <div className="text-center py-24"><p className="text-mute mb-5">لم نجد هذا الطلب. تأكد من الرابط الكامل.</p><Link to="/" className="btn btn-o">الرئيسية</Link></div>
  const fmt = (d: string) => new Date(d).toLocaleString('ar')
  return (
    <div className="max-w-xl mx-auto px-5 py-12">
      <p className="text-copper text-sm mb-1">تم استلام طلبك</p>
      <h1 className="font-display text-4xl mb-1">طلب رقم {o.order_number}</h1>
      <p className="mb-6">الحالة: <strong className="font-medium">{o.label}</strong></p>
      <ul className="bg-char2 divide-y divide-ivory/15 mb-4">{o.items.map((i, k) => <li key={k} className="p-4 flex justify-between"><span>{i.name} × {i.qty}</span><span>{money(i.price * i.qty, o.currency)}</span></li>)}</ul>
      <p className="flex justify-between font-medium mb-6"><span>الإجمالي</span><span>{money(o.total, o.currency)}</span></p>
      <p className="text-xs text-mute">أُنشئ: {fmt(o.created_at)} — آخر تحديث: {fmt(o.updated_at)}</p>
      <p className="text-xs text-mute mt-2">احتفظ برابط هذه الصفحة لمتابعة طلبك.</p>
    </div>
  )
}
