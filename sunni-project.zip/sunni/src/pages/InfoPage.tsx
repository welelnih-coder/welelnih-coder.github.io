import { useEffect, useState } from 'react'
import { useParams } from 'react-router-dom'
import { supabase } from '../lib/supabase'
export default function InfoPage() {
  const { slug } = useParams(); const [p, setP] = useState<{ title: string; body: string } | null | undefined>(undefined)
  useEffect(() => { setP(undefined); supabase.from('pages').select('title,body').eq('slug', slug!).eq('published', true).maybeSingle().then(r => setP(r.data)) }, [slug])
  if (p === undefined) return <p className="text-center text-mute py-24">جارٍ التحميل…</p>
  if (!p) return <p className="text-center text-mute py-24">الصفحة غير موجودة.</p>
  return <div className="max-w-2xl mx-auto px-5 py-12"><h1 className="font-display text-4xl mb-6">{p.title}</h1><div className="whitespace-pre-line text-ivory/85">{p.body}</div></div>
}
