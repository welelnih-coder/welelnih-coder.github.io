import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { supabase } from '../lib/supabase'
import { useSettings } from '../lib/settings'
import { PRODUCT_SELECT, publicUrl } from '../lib/util'
import type { Category, Product } from '../lib/types'
import ProductCard from '../components/ProductCard'
export default function Home() {
  const { settings } = useSettings()
  const [cats, setCats] = useState<Category[]>([]); const [feat, setFeat] = useState<Product[]>([]); const [latest, setLatest] = useState<Product[]>([])
  const [loading, setLoading] = useState(true)
  useEffect(() => {
    Promise.all([
      supabase.from('categories').select('*').order('sort_order'),
      supabase.from('products').select(PRODUCT_SELECT).eq('is_published', true).eq('is_featured', true).order('sort_order').limit(8),
      supabase.from('products').select(PRODUCT_SELECT).eq('is_published', true).order('created_at', { ascending: false }).limit(8),
    ]).then(([c, f, l]) => { setCats((c.data ?? []) as Category[]); setFeat((f.data ?? []) as Product[]); setLatest((l.data ?? []) as Product[]) }).finally(() => setLoading(false))
  }, [])
  const hero = publicUrl('store-assets', settings?.hero_image_path ?? null)
  return (
    <>
      <section className={`max-w-6xl mx-auto px-5 py-14 grid gap-10 items-center ${hero ? 'md:grid-cols-[1.1fr_.9fr]' : ''}`}>
        <div>
          <h1 className="font-display text-[clamp(40px,7vw,76px)] leading-tight mb-5">{settings?.hero_title || settings?.name_ar}</h1>
          {settings?.hero_text && <p className="text-ivory/75 max-w-lg mb-8">{settings.hero_text}</p>}
          <Link to="/shop" className="btn">اكتشف العطور</Link>
        </div>
        {hero && <img src={hero} alt="" className="w-full max-h-[560px] object-contain md:order-last order-first" />}
      </section>
      {cats.length > 0 && <section className="max-w-6xl mx-auto px-5 py-8 flex flex-wrap gap-3">
        {cats.map(c => <Link key={c.id} to={`/shop?cat=${c.slug}`} className="border border-ivory/15 px-5 py-2 rounded-full text-sm hover:border-copper">{c.name}</Link>)}
      </section>}
      {loading ? <p className="text-center text-mute py-16">جارٍ التحميل…</p> : (<>
        <Row title="المنتجات المميزة" items={feat} />
        <Row title="أحدث العطور" items={latest} />
        {feat.length === 0 && latest.length === 0 && <div className="max-w-6xl mx-auto px-5"><div className="bg-char2 text-center py-14 text-mute">لا توجد عطور منشورة حاليًا.</div></div>}
      </>)}
    </>
  )
}
function Row({ title, items }: { title: string; items: Product[] }) {
  if (items.length === 0) return null
  return <section className="max-w-6xl mx-auto px-5 py-10 border-t border-ivory/15">
    <div className="flex justify-between items-baseline mb-6"><h2 className="font-display text-3xl">{title}</h2><Link to="/shop" className="text-sm text-copper">عرض الكل</Link></div>
    <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6">{items.map(p => <ProductCard key={p.id} p={p} />)}</div>
  </section>
}
