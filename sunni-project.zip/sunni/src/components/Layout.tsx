import { useEffect } from 'react'
import { Link, Outlet, useNavigate } from 'react-router-dom'
import { useSettings } from '../lib/settings'
import { useCart } from '../lib/cart'
import { publicUrl } from '../lib/util'

export function Brand({ big = false }: { big?: boolean }) {
  const { settings } = useSettings()
  const logo = publicUrl('store-assets', settings?.logo_path ?? null)
  if (logo) return <img src={logo} alt={settings?.name_ar} className={big ? 'h-12' : 'h-9'} />
  return <span className="font-display text-3xl leading-none">{settings?.name_ar ?? 'سُنّي'}<small className="font-body text-[11px] tracking-[.3em] text-copper ms-2">{settings?.name_en ?? 'SUNNI'}</small></span>
}

export default function Layout() {
  const { settings, pages, loading, error } = useSettings()
  const { count } = useCart()
  const nav = useNavigate()
  useEffect(() => {
    if (!settings) return
    document.title = `${settings.name_ar} | ${settings.name_en}`
    const share = publicUrl('store-assets', (settings as unknown as { share_image_path?: string }).share_image_path ?? null)
    const og = (p: string, v: string) => { let m = document.querySelector<HTMLMetaElement>(`meta[property="${p}"]`); if (!m) { m = document.createElement('meta'); m.setAttribute('property', p); document.head.appendChild(m) } m.content = v }
    og('og:title', settings.name_ar); if (settings.description) og('og:description', settings.description); if (share) og('og:image', share)
    const fav = publicUrl('store-assets', settings.favicon_path)
    if (fav) { let l = document.querySelector<HTMLLinkElement>('link[rel=icon]'); if (!l) { l = document.createElement('link'); l.rel = 'icon'; document.head.appendChild(l) } l.href = fav }
  }, [settings])

  if (loading) return <div className="min-h-screen grid place-items-center text-mute">جارٍ التحميل…</div>
  if (error) return <div className="min-h-screen grid place-items-center text-center px-6 text-mute">تعذّر الاتصال بالمتجر. تحقق من الإنترنت ثم أعد المحاولة.<br /><button className="btn mt-4" onClick={() => location.reload()}>إعادة المحاولة</button></div>
  if (settings?.maintenance_mode) return <div className="min-h-screen grid place-items-center text-center px-6"><div><Brand big /><p className="mt-6 text-mute">المتجر مغلق مؤقتًا للصيانة. نعود قريبًا.</p></div></div>

  return (
    <div className="min-h-screen flex flex-col">
      <header className="sticky top-0 z-10 bg-char/90 backdrop-blur border-b border-ivory/15 pt-[env(safe-area-inset-top)]">
        <div className="max-w-6xl mx-auto px-5 h-16 flex items-center gap-5">
          <Link to="/" aria-label="الرئيسية"><Brand /></Link>
          <nav className="hidden sm:flex gap-6 text-[15px] text-ivory/80 ms-auto" aria-label="التنقل الرئيسي">
            <Link to="/shop">العطور</Link><Link to="/orders">طلباتي</Link>
          </nav>
          <div className="flex gap-1 ms-auto sm:ms-0">
            <button aria-label="بحث" className="w-11 h-11 grid place-items-center hover:bg-char2 rounded-full" onClick={() => nav('/shop?focus=1')}>
              <svg viewBox="0 0 24 24" className="w-5 h-5 fill-none stroke-current" strokeWidth="1.5"><circle cx="11" cy="11" r="6.5" /><path d="M16 16l4.5 4.5" /></svg>
            </button>
            <Link to="/cart" aria-label="سلة التسوق" className="relative w-11 h-11 grid place-items-center hover:bg-char2 rounded-full">
              <svg viewBox="0 0 24 24" className="w-5 h-5 fill-none stroke-current" strokeWidth="1.5"><path d="M5 8h14l-1.2 11H6.2z" /><path d="M9 8V6.5a3 3 0 016 0V8" /></svg>
              {count > 0 && <span className="absolute top-1 start-0.5 min-w-[18px] h-[18px] rounded-full bg-copper text-char text-[11px] leading-[18px] text-center">{count}</span>}
            </Link>
          </div>
        </div>
      </header>
      <main className="flex-1"><Outlet /></main>
      <footer className="border-t border-ivory/15 bg-[#171413] py-10 mt-16">
        <div className="max-w-6xl mx-auto px-5 grid gap-8 sm:grid-cols-3 text-sm">
          <div><Brand />{settings?.description && <p className="text-mute mt-3">{settings.description}</p>}</div>
          <div><h4 className="font-medium mb-2">الصفحات</h4>
            <ul className="text-mute space-y-1">{pages.length === 0 && <li>—</li>}{pages.map(p => <li key={p.slug}><Link to={`/p/${p.slug}`} className="hover:text-ivory">{p.title}</Link></li>)}</ul></div>
          <div><h4 className="font-medium mb-2">تواصل معنا</h4>
            <ul className="text-mute space-y-1">{settings?.city && <li>{settings.city}</li>}{settings?.phones.map(t => <li key={t} dir="ltr" className="text-end"><a href={`tel:${t}`}>{t}</a></li>)}</ul></div>
        </div>
        <p className="max-w-6xl mx-auto px-5 mt-8 text-xs text-mute">© {settings?.name_ar}. جميع الحقوق محفوظة.</p>
      </footer>
    </div>
  )
}
