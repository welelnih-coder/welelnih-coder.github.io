import { Link } from 'react-router-dom'
import type { Product } from '../lib/types'
import { useCart } from '../lib/cart'
import { useSettings } from '../lib/settings'
import { inStock, mainImage, money } from '../lib/util'
export default function ProductCard({ p }: { p: Product }) {
  const { add } = useCart(); const { settings } = useSettings()
  const img = mainImage(p); const ok = inStock(p); const cur = settings?.currency
  return (
    <article className="bg-char2 flex flex-col">
      <Link to={`/product/${p.id}`} className="block aspect-[4/5] bg-brown/40">
        {img ? <img src={img} alt={p.name} loading="lazy" className="w-full h-full object-contain" /> : <div className="w-full h-full grid place-items-center text-mute text-sm">بلا صورة</div>}
      </Link>
      <div className="p-4 flex-1 flex flex-col gap-2">
        <h3 className="font-medium">{p.name}</h3>
        <div className="flex items-baseline gap-2"><span>{money(p.price, cur)}</span>{p.compare_at_price && <s className="text-mute text-sm">{money(p.compare_at_price, cur)}</s>}</div>
        <span className={`text-xs ${ok ? 'text-copper' : 'text-mute'}`}>{ok ? 'متوفر' : 'غير متوفر'}</span>
        <div className="grid grid-cols-2 gap-2 mt-auto pt-2">
          <Link to={`/product/${p.id}`} className="btn btn-o text-center !px-2 !py-2 text-sm">عرض التفاصيل</Link>
          <button className="btn !px-2 !py-2 text-sm" disabled={!ok} onClick={() => add(p)}>أضف إلى السلة</button>
        </div>
      </div>
    </article>
  )
}
