import { createContext, useContext, useEffect, useState, ReactNode } from 'react'
import { supabase } from './supabase'
import type { Settings, PageLink } from './types'
type Ctx = { settings: Settings | null; pages: PageLink[]; loading: boolean; error: boolean }
const C = createContext<Ctx>({ settings: null, pages: [], loading: true, error: false })
export const useSettings = () => useContext(C)
export function SettingsProvider({ children }: { children: ReactNode }) {
  const [s, setS] = useState<Ctx>({ settings: null, pages: [], loading: true, error: false })
  useEffect(() => {
    Promise.all([
      supabase.from('store_settings').select('*').eq('id', 1).single(),
      supabase.from('pages').select('slug,title').eq('published', true),
    ]).then(([a, b]) => {
      if (a.error) return setS({ settings: null, pages: [], loading: false, error: true })
      setS({ settings: a.data as Settings, pages: (b.data ?? []) as PageLink[], loading: false, error: false })
    }).catch(() => setS({ settings: null, pages: [], loading: false, error: true }))
  }, [])
  return <C.Provider value={s}>{children}</C.Provider>
}
