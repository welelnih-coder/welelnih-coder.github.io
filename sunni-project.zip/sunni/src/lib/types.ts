export type Settings = {
  name_ar: string; name_en: string; description: string | null; logo_path: string | null; favicon_path: string | null
  hero_image_path: string | null; hero_title: string | null; hero_text: string | null; phones: string[]; city: string | null
  delivery_info: string | null; delivery_fee: number; currency: string; payment_methods: string[]; maintenance_mode: boolean
}
export type Category = { id: string; name: string; slug: string }
export type Product = {
  id: string; name: string; description: string | null; price: number; compare_at_price: number | null
  stock: number; size_info: string | null; is_available: boolean; is_featured: boolean; category_id: string | null
  product_images: { path: string; is_main: boolean; sort_order: number }[]
}
export type PageLink = { slug: string; title: string }
