import { createContext, useContext, useEffect, useState, useCallback, ReactNode } from 'react'
import type { User } from '@supabase/supabase-js'
import { supabase } from './supabase'
type A = { loading: boolean; user: User | null; isAdmin: boolean; mustChange: boolean; recovery: boolean; refresh: () => Promise<void> }
const C = createContext<A>(null as unknown as A)
export const useAuth = () => useContext(C)
export function AuthProvider({ children }: { children: ReactNode }) {
  const [s, setS] = useState({ loading: true, user: null as User | null, isAdmin: false, mustChange: false })
  const [recovery, setRecovery] = useState(false)
  const load = useCallback(async (user: User | null) => {
    if (!user) return setS({ loading: false, user: null, isAdmin: false, mustChange: false })
    const { data } = await supabase.from('admins').select('must_change_password').eq('user_id', user.id).maybeSingle()
    setS({ loading: false, user, isAdmin: !!data, mustChange: !!data?.must_change_password })
  }, [])
  const refresh = useCallback(async () => { const { data } = await supabase.auth.getSession(); await load(data.session?.user ?? null) }, [load])
  useEffect(() => {
    refresh()
    const { data: sub } = supabase.auth.onAuthStateChange((ev, session) => {
      if (ev === 'PASSWORD_RECOVERY') setRecovery(true)
      setTimeout(() => load(session?.user ?? null), 0)
    })
    return () => sub.subscription.unsubscribe()
  }, [refresh, load])
  return <C.Provider value={{ ...s, recovery, refresh }}>{children}</C.Provider>
}
