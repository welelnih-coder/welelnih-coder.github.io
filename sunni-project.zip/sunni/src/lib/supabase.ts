import { createClient } from '@supabase/supabase-js'
// المفتاح العام (anon) مصمَّم ليكون ظاهرًا؛ الحماية الحقيقية في سياسات RLS داخل قاعدة البيانات.
export const supabase = createClient(import.meta.env.VITE_SUPABASE_URL, import.meta.env.VITE_SUPABASE_ANON_KEY)
