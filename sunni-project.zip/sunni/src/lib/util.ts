import { supabase } from './supabase'
import type { Product } from './types'
export const money = (n: number, cur = 'MRU') => `${Number(n).toLocaleString('en-US')} ${cur}`
export const publicUrl = (bucket: string, path: string | null) => path ? supabase.storage.from(bucket).getPublicUrl(path).data.publicUrl : null
export const mainImage = (p: Product) => {
  const imgs = [...p.product_images].sort((a, b) => Number(b.is_main) - Number(a.is_main) || a.sort_order - b.sort_order)
  return imgs[0] ? publicUrl('product-images', imgs[0].path) : null
}
export const inStock = (p: Product) => p.is_available && p.stock > 0
export const PRODUCT_SELECT = '*, product_images(path,is_main,sort_order)'
