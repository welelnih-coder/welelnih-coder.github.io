import { createContext, useContext, useEffect, useState, ReactNode } from 'react'
import type { Product } from './types'
import { mainImage } from './util'
export type Line = { id: string; name: string; price: number; qty: number; stock: number; image: string | null }
type Ctx = { lines: Line[]; count: number; subtotal: number; add: (p: Product) => void; setQty: (id: string, q: number) => void; remove: (id: string) => void; clear: () => void }
const C = createContext<Ctx>(null as unknown as Ctx)
export const useCart = () => useContext(C)
const KEY = 'sunni_cart'
export function CartProvider({ children }: { children: ReactNode }) {
  const [lines, setLines] = useState<Line[]>(() => { try { return JSON.parse(localStorage.getItem(KEY) || '[]') } catch { return [] } })
  useEffect(() => { try { localStorage.setItem(KEY, JSON.stringify(lines)) } catch { /* التخزين غير متاح */ } }, [lines])
  const add = (p: Product) => setLines(ls => {
    const f = ls.find(l => l.id === p.id)
    if (f) return ls.map(l => l.id === p.id ? { ...l, qty: Math.min(l.qty + 1, p.stock), stock: p.stock, price: p.price } : l)
    return [...ls, { id: p.id, name: p.name, price: p.price, qty: 1, stock: p.stock, image: mainImage(p) }]
  })
  const setQty = (id: string, q: number) => setLines(ls => ls.map(l => l.id === id ? { ...l, qty: Math.max(1, Math.min(q, l.stock)) } : l))
  const remove = (id: string) => setLines(ls => ls.filter(l => l.id !== id))
  const clear = () => setLines([])
  const count = lines.reduce((a, l) => a + l.qty, 0)
  const subtotal = lines.reduce((a, l) => a + l.qty * l.price, 0)
  return <C.Provider value={{ lines, count, subtotal, add, setQty, remove, clear }}>{children}</C.Provider>
}
