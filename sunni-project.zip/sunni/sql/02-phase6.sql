-- المرحلة 6 (آمن للتشغيل أكثر من مرة). يُشغَّل بعد 01-schema.sql
alter table public.notification_settings add column if not exists config jsonb not null default '{}'::jsonb;
do $$ begin
  if not exists (select 1 from pg_publication_tables where pubname = 'supabase_realtime' and schemaname = 'public' and tablename = 'admin_inbox') then
    alter publication supabase_realtime add table public.admin_inbox;
  end if;
end $$;
