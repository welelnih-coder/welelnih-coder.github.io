-- =====================================================================
-- سُنّي | SUNNI — مخطط قاعدة البيانات v2 (Supabase / PostgreSQL 15)
-- شغّله مرة واحدة على مشروع جديد: SQL Editor ← New query ← Run
-- الملف كله داخل معاملة واحدة: إن فشل أي سطر يُلغى كل شيء ويمكن إعادة التشغيل.
-- لا يحتوي على منتجات أو طلبات أو حسابات تجريبية أو كلمات مرور.
-- =====================================================================
begin;

create extension if not exists pgcrypto;

-- ---------- 1) المشرفون ----------
create table public.admins (
  user_id uuid primary key references auth.users(id) on delete cascade,
  role text not null default 'admin' check (role in ('admin','staff')),
  must_change_password boolean not null default true,
  created_at timestamptz not null default now()
);

create function public.is_admin()
returns boolean language sql stable security definer set search_path = public, pg_temp as $$
  select exists (select 1 from public.admins where user_id = auth.uid());
$$;

-- ---------- 2) إعدادات المتجر (صف واحد) ----------
create table public.store_settings (
  id int primary key default 1 check (id = 1),
  name_ar text not null default 'سُنّي',
  name_en text not null default 'SUNNI',
  description text,
  logo_path text,
  favicon_path text,
  share_image_path text,
  hero_image_path text,
  hero_title text,
  hero_text text,
  phones text[] not null default '{}',
  city text,
  delivery_info text,
  delivery_fee numeric(12,2) not null default 0 check (delivery_fee >= 0),
  currency text not null default 'MRU',
  payment_methods jsonb not null default '[]'::jsonb,
  maintenance_mode boolean not null default false,
  updated_at timestamptz not null default now()
);
insert into public.store_settings (id) values (1);

-- ---------- 3) الصفحات ----------
create table public.pages (
  slug text primary key,
  title text not null,
  body text not null default '',
  published boolean not null default false,
  updated_at timestamptz not null default now()
);

-- ---------- 4) التصنيفات ----------
create table public.categories (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  slug text not null unique,
  sort_order int not null default 0,
  created_at timestamptz not null default now()
);

-- ---------- 5) المنتجات ----------
create table public.products (
  id uuid primary key default gen_random_uuid(),
  name text not null check (char_length(name) between 1 and 200),
  description text,
  price numeric(12,2) not null check (price >= 0),
  compare_at_price numeric(12,2) check (compare_at_price is null or compare_at_price > price),
  category_id uuid references public.categories(id) on delete set null,
  stock int not null default 0 check (stock >= 0),
  size_info text,
  options jsonb not null default '{}'::jsonb,
  is_available boolean not null default true,
  is_published boolean not null default false,
  is_featured boolean not null default false,
  sort_order int not null default 0,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index on public.products (is_published, created_at desc);
create index on public.products (category_id);

create table public.product_images (
  id uuid primary key default gen_random_uuid(),
  product_id uuid not null references public.products(id) on delete cascade,
  path text not null,
  is_main boolean not null default false,
  sort_order int not null default 0
);
create index on public.product_images (product_id);

-- ---------- 6) حالات الطلب ----------
create table public.order_statuses (
  key text primary key,
  label text not null,
  sort_order int not null
);
insert into public.order_statuses (key, label, sort_order) values
  ('new','جديد',1),
  ('confirmed','تم تأكيد الطلب',2),
  ('preparing','قيد التجهيز',3),
  ('out_for_delivery','خرج للتوصيل',4),
  ('completed','مكتمل',5),
  ('cancelled','ملغى',6);

-- ---------- 7) الطلبات ----------
create table public.orders (
  id uuid primary key default gen_random_uuid(),
  order_number bigint generated always as identity (start with 1001) unique,
  public_token uuid not null default gen_random_uuid(),
  idempotency_key text not null unique,
  customer_name text not null,
  phone text not null,
  city text not null,
  address text,
  notes text,
  subtotal numeric(12,2) not null check (subtotal >= 0),
  delivery_fee numeric(12,2) not null default 0 check (delivery_fee >= 0),
  total numeric(12,2) not null check (total >= 0),
  currency text not null,
  status text not null default 'new' references public.order_statuses(key),
  internal_notes text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index on public.orders (status, created_at desc);
create index on public.orders (created_at desc);
create index on public.orders (phone);

create table public.order_items (
  id uuid primary key default gen_random_uuid(),
  order_id uuid not null references public.orders(id) on delete cascade,
  product_id uuid references public.products(id) on delete set null,
  product_name text not null,
  unit_price numeric(12,2) not null,
  quantity int not null check (quantity > 0),
  line_total numeric(12,2) not null
);
create index on public.order_items (order_id);

create table public.order_status_log (
  id bigint generated always as identity primary key,
  order_id uuid not null references public.orders(id) on delete cascade,
  from_status text,
  to_status text not null,
  changed_by uuid,
  changed_at timestamptz not null default now()
);
create index on public.order_status_log (order_id);

-- ---------- 8) الإشعارات (بلا أسرار؛ المفاتيح في Supabase Secrets) ----------
create table public.notification_settings (
  channel text primary key check (channel in ('admin_inbox','email','web_push','sms')),
  enabled boolean not null default false,
  state text not null default 'needs_setup' check (state in ('active','disabled','needs_setup','error')),
  last_error text,
  config jsonb not null default '{}'::jsonb,
  updated_at timestamptz not null default now()
);
insert into public.notification_settings (channel, enabled, state) values
  ('admin_inbox', true, 'active'),
  ('email', false, 'needs_setup'),
  ('web_push', false, 'needs_setup'),
  ('sms', false, 'needs_setup');

create table public.admin_inbox (
  id bigint generated always as identity primary key,
  order_id uuid references public.orders(id) on delete cascade,
  message text not null,
  is_read boolean not null default false,
  created_at timestamptz not null default now()
);

-- ---------- 9) المشغلات ----------
create function public.touch_updated_at()
returns trigger language plpgsql set search_path = public, pg_temp as $$
begin new.updated_at = now(); return new; end $$;

create trigger t_products_touch before update on public.products for each row execute function public.touch_updated_at();
create trigger t_settings_touch before update on public.store_settings for each row execute function public.touch_updated_at();
create trigger t_pages_touch before update on public.pages for each row execute function public.touch_updated_at();
create trigger t_notif_touch before update on public.notification_settings for each row execute function public.touch_updated_at();

-- يُسمح بتعديل الحالة والملاحظات الداخلية فقط؛ بقية بيانات الطلب ثابتة.
-- الطلب الملغى لا يُعاد فتحه (لأن الإلغاء يعيد المخزون ولا يوجد خصم جديد).
create function public.on_order_update()
returns trigger language plpgsql security definer set search_path = public, pg_temp as $$
begin
  if (new.id, new.order_number, new.public_token, new.idempotency_key, new.customer_name, new.phone, new.city,
      new.address, new.notes, new.subtotal, new.delivery_fee, new.total, new.currency, new.created_at)
     is distinct from
     (old.id, old.order_number, old.public_token, old.idempotency_key, old.customer_name, old.phone, old.city,
      old.address, old.notes, old.subtotal, old.delivery_fee, old.total, old.currency, old.created_at)
  then raise exception 'order_fields_immutable'; end if;

  if new.status is distinct from old.status then
    if old.status = 'cancelled' then raise exception 'cancelled_order_locked'; end if;
    new.updated_at = now();
    insert into public.order_status_log (order_id, from_status, to_status, changed_by)
      values (new.id, old.status, new.status, auth.uid());
    if new.status = 'cancelled' then
      update public.products p set stock = p.stock + i.quantity
        from public.order_items i
        where i.order_id = new.id and i.product_id = p.id;
    end if;
  end if;
  return new;
end $$;
create trigger t_orders_update before update on public.orders for each row execute function public.on_order_update();

-- ---------- 10) إنشاء الطلب ----------
create function public.create_order(
  p_name text, p_phone text, p_city text, p_address text, p_notes text,
  p_items jsonb, p_key text
) returns jsonb
language plpgsql security definer set search_path = public, pg_temp as $$
declare
  s public.store_settings;
  o public.orders;
  prod public.products;
  r record; e jsonb;
  v_phone text := regexp_replace(coalesce(p_phone, ''), '\s', '', 'g');
  v_name text := trim(coalesce(p_name, ''));
  v_city text := trim(coalesce(p_city, ''));
  subtotal numeric(12,2) := 0;
  built jsonb := '[]'::jsonb;
begin
  if p_key is null or char_length(p_key) < 16 or char_length(p_key) > 100 then raise exception 'invalid_request'; end if;

  -- يُسلسل الطلبات ذات المفتاح نفسه، فلا ينشأ طلبان من نقرتين متزامنتين
  perform pg_advisory_xact_lock(hashtextextended(p_key, 0));
  select * into o from public.orders where idempotency_key = p_key;
  if found then
    return jsonb_build_object('order_number', o.order_number, 'token', o.public_token,
                              'total', o.total, 'status', o.status, 'duplicate', true);
  end if;

  select * into s from public.store_settings where id = 1;
  if s.maintenance_mode then raise exception 'store_closed'; end if;

  if v_name = '' or char_length(v_name) > 120 or v_city = '' or char_length(v_city) > 120
     or v_phone !~ '^\+?[0-9]{6,15}$'
     or char_length(coalesce(p_address, '')) > 400 or char_length(coalesce(p_notes, '')) > 600
     or p_items is null or jsonb_typeof(p_items) <> 'array' or jsonb_array_length(p_items) not between 1 and 30
  then raise exception 'invalid_input'; end if;

  for e in select * from jsonb_array_elements(p_items) loop
    if jsonb_typeof(e) <> 'object'
       or coalesce(e->>'product_id', '') !~* '^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$'
       or coalesce(e->>'qty', '') !~ '^[0-9]{1,2}$'
    then raise exception 'invalid_input'; end if;
    if (e->>'qty')::int not between 1 and 50 then raise exception 'invalid_quantity'; end if;
  end loop;

  -- حدود ضد الإغراق: 5 طلبات/ساعة لكل هاتف و300 طلب/ساعة للمتجر كله
  if (select count(*) from public.orders where phone = v_phone and created_at > now() - interval '1 hour') >= 5
     or (select count(*) from public.orders where created_at > now() - interval '1 hour') >= 300
  then raise exception 'too_many_requests'; end if;

  -- دمج المنتج المكرر في سطر واحد، وقفل الصفوف بترتيب ثابت (يمنع التعطل المتبادل Deadlock)،
  -- ثم فحص المخزون وخصمه داخل المعاملة نفسها.
  for r in
    select (x->>'product_id')::uuid as pid, sum((x->>'qty')::int)::int as qty
    from jsonb_array_elements(p_items) x group by 1 order by 1
  loop
    if r.qty > 100 then raise exception 'invalid_quantity'; end if;
    select * into prod from public.products
      where id = r.pid and is_published and is_available for update;
    if not found then raise exception 'product_unavailable'; end if;
    if prod.stock < r.qty then raise exception 'insufficient_stock:%', prod.name; end if;
    update public.products set stock = stock - r.qty where id = prod.id;
    subtotal := subtotal + prod.price * r.qty;
    built := built || jsonb_build_array(jsonb_build_object('id', prod.id, 'name', prod.name, 'price', prod.price, 'qty', r.qty));
  end loop;

  insert into public.orders (idempotency_key, customer_name, phone, city, address, notes,
                             subtotal, delivery_fee, total, currency)
  values (p_key, v_name, v_phone, v_city, nullif(trim(coalesce(p_address, '')), ''), nullif(trim(coalesce(p_notes, '')), ''),
          subtotal, s.delivery_fee, subtotal + s.delivery_fee, s.currency)
  returning * into o;

  insert into public.order_items (order_id, product_id, product_name, unit_price, quantity, line_total)
  select o.id, (b->>'id')::uuid, b->>'name', (b->>'price')::numeric, (b->>'qty')::int,
         (b->>'price')::numeric * (b->>'qty')::int
  from jsonb_array_elements(built) b;

  insert into public.order_status_log (order_id, to_status) values (o.id, 'new');
  insert into public.admin_inbox (order_id, message) values (o.id, 'طلب جديد رقم ' || o.order_number);

  return jsonb_build_object('order_number', o.order_number, 'token', o.public_token,
                            'total', o.total, 'status', o.status, 'duplicate', false);
end $$;

create function public.get_order_status(p_number bigint, p_token uuid)
returns jsonb language sql stable security definer set search_path = public, pg_temp as $$
  select jsonb_build_object(
    'order_number', o.order_number, 'status', o.status, 'label', st.label,
    'total', o.total, 'currency', o.currency, 'created_at', o.created_at, 'updated_at', o.updated_at,
    'items', (select coalesce(jsonb_agg(jsonb_build_object('name', i.product_name, 'qty', i.quantity, 'price', i.unit_price)), '[]'::jsonb)
              from public.order_items i where i.order_id = o.id))
  from public.orders o join public.order_statuses st on st.key = o.status
  where o.order_number = p_number and o.public_token = p_token;
$$;

create function public.mark_password_changed()
returns void language sql security definer set search_path = public, pg_temp as $$
  update public.admins set must_change_password = false where user_id = auth.uid();
$$;

-- ---------- 11) صلاحيات الجداول والدوال (طبقة أولى قبل RLS) ----------
-- Supabase يمنح anon وauthenticated صلاحيات واسعة افتراضيًا؛ نسحبها ثم نمنح الحد الأدنى.
revoke all on all tables in schema public from anon, authenticated;
revoke all on all sequences in schema public from anon, authenticated;
revoke execute on all functions in schema public from public, anon, authenticated;

grant select on public.store_settings, public.pages, public.categories, public.products,
                public.product_images, public.order_statuses to anon, authenticated;
grant update on public.store_settings, public.order_statuses, public.orders, public.notification_settings to authenticated;
grant insert, update, delete on public.pages, public.categories, public.products, public.product_images to authenticated;
grant select on public.orders, public.order_items, public.order_status_log, public.notification_settings,
                public.admin_inbox, public.admins to authenticated;
grant update, delete on public.admin_inbox to authenticated;

grant execute on function public.is_admin() to anon, authenticated;   -- تحتاجها سياسات RLS
grant execute on function public.create_order(text,text,text,text,text,jsonb,text) to anon, authenticated;
grant execute on function public.get_order_status(bigint,uuid) to anon, authenticated;
grant execute on function public.mark_password_changed() to authenticated;

-- ---------- 12) سياسات RLS ----------
alter table public.admins                enable row level security;
alter table public.store_settings        enable row level security;
alter table public.pages                 enable row level security;
alter table public.categories            enable row level security;
alter table public.products              enable row level security;
alter table public.product_images        enable row level security;
alter table public.order_statuses        enable row level security;
alter table public.orders                enable row level security;
alter table public.order_items           enable row level security;
alter table public.order_status_log      enable row level security;
alter table public.notification_settings enable row level security;
alter table public.admin_inbox           enable row level security;

-- قراءة عامة لما يخص الواجهة فقط
create policy "read settings"   on public.store_settings for select using (true);
create policy "read pages"      on public.pages for select using (published or public.is_admin());
create policy "read categories" on public.categories for select using (true);
create policy "read products"   on public.products for select using (is_published or public.is_admin());
create policy "read images"     on public.product_images for select using (
  exists (select 1 from public.products p where p.id = product_images.product_id and (p.is_published or public.is_admin())));
create policy "read statuses"   on public.order_statuses for select using (true);

-- كتابة الإدارة (سياسات منفصلة لكل أمر؛ لا حذف للإعدادات ولا للطلبات)
create policy "admin update settings" on public.store_settings for update using (public.is_admin()) with check (public.is_admin() and id = 1);
create policy "admin update statuses" on public.order_statuses for update using (public.is_admin()) with check (public.is_admin());
create policy "admin write pages"      on public.pages for all using (public.is_admin()) with check (public.is_admin());
create policy "admin write categories" on public.categories for all using (public.is_admin()) with check (public.is_admin());
create policy "admin write products"   on public.products for all using (public.is_admin()) with check (public.is_admin());
create policy "admin write images"     on public.product_images for all using (public.is_admin()) with check (public.is_admin());

-- الطلبات وبيانات العملاء: للإدارة فقط. الزائر لا يقرأ ولا يكتب مباشرة (فقط عبر الدالتين).
create policy "admin read orders"    on public.orders for select using (public.is_admin());
create policy "admin update orders"  on public.orders for update using (public.is_admin()) with check (public.is_admin());
create policy "admin read items"     on public.order_items for select using (public.is_admin());
create policy "admin read log"       on public.order_status_log for select using (public.is_admin());
create policy "admin read notif"     on public.notification_settings for select using (public.is_admin());
create policy "admin update notif"   on public.notification_settings for update using (public.is_admin()) with check (public.is_admin());
create policy "admin read inbox"     on public.admin_inbox for select using (public.is_admin());
create policy "admin update inbox"   on public.admin_inbox for update using (public.is_admin()) with check (public.is_admin());
create policy "admin delete inbox"   on public.admin_inbox for delete using (public.is_admin());
create policy "admin read self"      on public.admins for select using (user_id = auth.uid());

-- ---------- 13) تخزين الصور ----------
-- الحاويتان عامتان: روابط الصور تعمل للزوار دون سياسة قراءة (فلا تُفهرس الملفات).
-- لا SVG: ملف SVG قد يحمل سكربتًا عند فتحه مباشرة.
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types) values
  ('product-images', 'product-images', true, 5242880, array['image/jpeg','image/png','image/webp']),
  ('store-assets',   'store-assets',   true, 3145728, array['image/jpeg','image/png','image/webp','image/x-icon','image/vnd.microsoft.icon'])
on conflict (id) do update set public = excluded.public, file_size_limit = excluded.file_size_limit,
                               allowed_mime_types = excluded.allowed_mime_types;

create policy "admin read assets" on storage.objects for select to authenticated
  using (bucket_id in ('product-images','store-assets') and public.is_admin());
create policy "admin upload assets" on storage.objects for insert to authenticated
  with check (bucket_id in ('product-images','store-assets') and public.is_admin());
create policy "admin update assets" on storage.objects for update to authenticated
  using (bucket_id in ('product-images','store-assets') and public.is_admin())
  with check (bucket_id in ('product-images','store-assets') and public.is_admin());
create policy "admin delete assets" on storage.objects for delete to authenticated
  using (bucket_id in ('product-images','store-assets') and public.is_admin());

commit;
