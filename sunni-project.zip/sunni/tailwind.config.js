export default {
  content: ['./index.html', './src/**/*.{ts,tsx}'],
  theme: { extend: {
    colors: { char: '#1c1917', char2: '#262220', ivory: '#f3ede3', brown: '#3b2a20', copper: '#a9774f', mute: '#8d8379' },
    fontFamily: { display: ['"Aref Ruqaa"', 'Amiri', 'serif'], body: ['"IBM Plex Sans Arabic"', 'Tahoma', 'sans-serif'] }
  } }
}
